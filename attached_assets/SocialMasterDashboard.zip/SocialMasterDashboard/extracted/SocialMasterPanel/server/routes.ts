import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertKeywordSchema, insertMessageSchema, insertScheduledContentSchema, insertSocialAccountSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import fs from "fs";
import { v4 as uuidv4 } from "uuid";

// Video yükleme için multer ayarları
const storage_upload = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadsDir = path.join(__dirname, "../uploads");
    // Dizin yoksa oluştur
    if (!fs.existsSync(uploadsDir)) {
      fs.mkdirSync(uploadsDir, { recursive: true });
    }
    cb(null, uploadsDir);
  },
  filename: (req, file, cb) => {
    const uniquePrefix = uuidv4();
    cb(null, `${uniquePrefix}_${file.originalname}`);
  }
});

const upload = multer({
  storage: storage_upload,
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB limit
  },
  fileFilter: (req, file, cb) => {
    const validTypes = ["video/mp4", "video/quicktime", "video/x-msvideo", "video/webm"];
    if (validTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Desteklenmeyen dosya formatı. Lütfen MP4, MOV, AVI veya WEBM formatında video yükleyin.") as any);
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.get("/api/user/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Geçersiz kullanıcı kimliği" });
    }

    const user = await storage.getUser(id);
    if (!user) {
      return res.status(404).json({ message: "Kullanıcı bulunamadı" });
    }

    // Don't send password in response
    const { password, ...userData } = user;
    res.json(userData);
  });

  // Social Account routes
  app.get("/api/accounts/:userId", async (req, res) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Geçersiz kullanıcı kimliği" });
    }

    const accounts = await storage.getSocialAccounts(userId);
    res.json(accounts);
  });

  app.post("/api/accounts", async (req, res) => {
    try {
      const accountData = insertSocialAccountSchema.parse(req.body);
      const account = await storage.createSocialAccount(accountData);
      res.status(201).json(account);
    } catch (error) {
      res.status(400).json({ message: "Geçersiz hesap verisi", error });
    }
  });

  app.put("/api/accounts/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Geçersiz hesap kimliği" });
    }

    try {
      const accountData = insertSocialAccountSchema.partial().parse(req.body);
      const account = await storage.updateSocialAccount(id, accountData);
      
      if (!account) {
        return res.status(404).json({ message: "Hesap bulunamadı" });
      }
      
      res.json(account);
    } catch (error) {
      res.status(400).json({ message: "Geçersiz hesap verisi", error });
    }
  });

  app.delete("/api/accounts/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Geçersiz hesap kimliği" });
    }

    const success = await storage.deleteSocialAccount(id);
    if (!success) {
      return res.status(404).json({ message: "Hesap bulunamadı" });
    }

    res.status(204).send();
  });

  // Message routes
  app.get("/api/messages/:accountId", async (req, res) => {
    const accountId = parseInt(req.params.accountId);
    if (isNaN(accountId)) {
      return res.status(400).json({ message: "Geçersiz hesap kimliği" });
    }

    const messages = await storage.getMessages(accountId);
    res.json(messages);
  });

  app.get("/api/messages/unread/:accountId", async (req, res) => {
    const accountId = parseInt(req.params.accountId);
    if (isNaN(accountId)) {
      return res.status(400).json({ message: "Geçersiz hesap kimliği" });
    }

    const count = await storage.getUnreadMessageCount(accountId);
    res.json({ unreadCount: count });
  });

  app.post("/api/messages", async (req, res) => {
    try {
      const messageData = insertMessageSchema.parse(req.body);
      const message = await storage.createMessage(messageData);
      res.status(201).json(message);
    } catch (error) {
      res.status(400).json({ message: "Geçersiz mesaj verisi", error });
    }
  });

  app.put("/api/messages/:id/read", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Geçersiz mesaj kimliği" });
    }

    const success = await storage.markMessageAsRead(id);
    if (!success) {
      return res.status(404).json({ message: "Mesaj bulunamadı" });
    }

    res.status(204).send();
  });

  // Activity routes
  app.get("/api/activities/:accountId", async (req, res) => {
    const accountId = parseInt(req.params.accountId);
    if (isNaN(accountId)) {
      return res.status(400).json({ message: "Geçersiz hesap kimliği" });
    }

    const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
    const activities = await storage.getActivities(accountId, limit);
    res.json(activities);
  });

  app.get("/api/activities/user/:userId", async (req, res) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Geçersiz kullanıcı kimliği" });
    }

    const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
    const activities = await storage.getActivitiesByUser(userId, limit);
    res.json(activities);
  });

  // Keyword routes
  app.get("/api/keywords/:userId", async (req, res) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Geçersiz kullanıcı kimliği" });
    }

    const platform = req.query.platform as string | undefined;
    
    const keywords = platform 
      ? await storage.getKeywordsByPlatform(userId, platform)
      : await storage.getKeywords(userId);
      
    res.json(keywords);
  });

  app.post("/api/keywords", async (req, res) => {
    try {
      const keywordData = insertKeywordSchema.parse(req.body);
      const keyword = await storage.createKeyword(keywordData);
      res.status(201).json(keyword);
    } catch (error) {
      res.status(400).json({ message: "Geçersiz anahtar kelime verisi", error });
    }
  });

  app.put("/api/keywords/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Geçersiz anahtar kelime kimliği" });
    }

    try {
      const keywordData = insertKeywordSchema.partial().parse(req.body);
      const keyword = await storage.updateKeyword(id, keywordData);
      
      if (!keyword) {
        return res.status(404).json({ message: "Anahtar kelime bulunamadı" });
      }
      
      res.json(keyword);
    } catch (error) {
      res.status(400).json({ message: "Geçersiz anahtar kelime verisi", error });
    }
  });

  app.delete("/api/keywords/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Geçersiz anahtar kelime kimliği" });
    }

    const success = await storage.deleteKeyword(id);
    if (!success) {
      return res.status(404).json({ message: "Anahtar kelime bulunamadı" });
    }

    res.status(204).send();
  });

  // Analytics routes
  app.get("/api/analytics/:accountId", async (req, res) => {
    const accountId = parseInt(req.params.accountId);
    if (isNaN(accountId)) {
      return res.status(400).json({ message: "Geçersiz hesap kimliği" });
    }

    const startDateStr = req.query.startDate as string;
    const endDateStr = req.query.endDate as string;

    if (!startDateStr || !endDateStr) {
      return res.status(400).json({ message: "Başlangıç ve bitiş tarihleri gereklidir" });
    }

    const startDate = new Date(startDateStr);
    const endDate = new Date(endDateStr);

    if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
      return res.status(400).json({ message: "Geçersiz tarih formatı" });
    }

    const analytics = await storage.getAnalytics(accountId, startDate, endDate);
    res.json(analytics);
  });

  // Content scheduling routes
  app.get("/api/content/:accountId", async (req, res) => {
    const accountId = parseInt(req.params.accountId);
    if (isNaN(accountId)) {
      return res.status(400).json({ message: "Geçersiz hesap kimliği" });
    }

    const content = await storage.getScheduledContent(accountId);
    res.json(content);
  });

  app.post("/api/content", async (req, res) => {
    try {
      const contentData = insertScheduledContentSchema.parse(req.body);
      const content = await storage.createScheduledContent(contentData);
      res.status(201).json(content);
    } catch (error) {
      res.status(400).json({ message: "Geçersiz içerik verisi", error });
    }
  });

  app.put("/api/content/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Geçersiz içerik kimliği" });
    }

    try {
      const contentData = insertScheduledContentSchema.partial().parse(req.body);
      const content = await storage.updateScheduledContent(id, contentData);
      
      if (!content) {
        return res.status(404).json({ message: "İçerik bulunamadı" });
      }
      
      res.json(content);
    } catch (error) {
      res.status(400).json({ message: "Geçersiz içerik verisi", error });
    }
  });

  app.delete("/api/content/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Geçersiz içerik kimliği" });
    }

    const success = await storage.deleteScheduledContent(id);
    if (!success) {
      return res.status(404).json({ message: "İçerik bulunamadı" });
    }

    res.status(204).send();
  });

  // Dashboard summary endpoint
  app.get("/api/dashboard/:userId", async (req, res) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Geçersiz kullanıcı kimliği" });
    }

    // Get all accounts for this user
    const accounts = await storage.getSocialAccounts(userId);
    
    // Calculate total followers and unread messages
    let totalFollowers = 0;
    let totalUnreadMessages = 0;
    let accountStats = {};

    for (const account of accounts) {
      if (account.stats && account.stats.followers) {
        totalFollowers += account.stats.followers;
      }
      
      const unreadCount = await storage.getUnreadMessageCount(account.id);
      totalUnreadMessages += unreadCount;
      
      // Store count by platform
      // TypeScript hata giderme düzeltmesi
      const platform = account.platform;
      accountStats = {
        ...accountStats,
        [platform]: {
          ...(accountStats[platform] || {}),
          followers: ((accountStats[platform] || {}).followers || 0) + (account.stats?.followers || 0),
          unreadMessages: ((accountStats[platform] || {}).unreadMessages || 0) + unreadCount
        }
      };
    }

    // Get recent activities
    const recentActivities = await storage.getActivitiesByUser(userId, 5);
    
    // Return the dashboard data
    res.json({
      totalFollowers,
      totalUnreadMessages,
      accountStats,
      recentActivities,
      accountCount: accounts.length
    });
  });

  // Video yükleme ve işleme endpoint'i
  app.post("/api/content/upload-video", upload.single("video"), async (req, res) => {
    try {
      // Dosya yüklenmemiş ise hata döndür
      if (!req.file) {
        return res.status(400).json({ 
          message: "Video dosyası bulunamadı. Lütfen bir video yükleyin." 
        });
      }
      
      const { title, caption, hashtags, platforms, privacyLevel } = req.body;
      
      if (!title || !platforms) {
        return res.status(400).json({ 
          message: "Başlık ve en az bir platform seçilmelidir." 
        });
      }
      
      // JSON stringini parse et
      let platformsList = [];
      try {
        platformsList = JSON.parse(platforms);
      } catch (error) {
        return res.status(400).json({ 
          message: "Platform bilgisi geçersiz format." 
        });
      }
      
      if (!Array.isArray(platformsList) || platformsList.length === 0) {
        return res.status(400).json({ 
          message: "En az bir platform seçilmelidir." 
        });
      }
      
      // Zamanlama bilgisi
      let scheduledDate = null;
      if (req.body.scheduled === "true" && req.body.scheduledDate) {
        scheduledDate = new Date(req.body.scheduledDate);
        if (isNaN(scheduledDate.getTime())) {
          return res.status(400).json({ message: "Geçersiz tarih formatı" });
        }
      }
      
      // Video dosya bilgisi
      const videoPath = req.file.path;
      const videoUrl = `/uploads/${path.basename(videoPath)}`;
      
      // Her platform için içerik kayıt edilir
      const createdContents = [];
      
      for (const platform of platformsList) {
        // Kullanıcının bu platforma ait hesaplarını bul
        // Gerçek uygulamada kullanıcı bilgisi oturumdan alınacaktır
        const userId = 1; // Şimdilik demo olarak 1 numaralı kullanıcı
        const accounts = await storage.getSocialAccounts(userId);
        const platformAccount = accounts.find(acc => acc.platform === platform);
        
        if (!platformAccount) {
          continue; // Bu platformda hesap bulunamadı, diğerine geç
        }
        
        // İçerik oluştur
        const contentData = {
          content: caption || title,
          platform: platform,
          socialAccountId: platformAccount.id,
          scheduledFor: scheduledDate || new Date(),
          status: scheduledDate ? "SCHEDULED" : "PENDING",
          mediaUrls: [videoUrl]
        };
        
        // Veri tabanına kaydet
        const content = await storage.createScheduledContent(contentData);
        createdContents.push(content);
        
        // Aktivite kaydı ekle
        const activityData = {
          platform: platform,
          socialAccountId: platformAccount.id,
          activityType: "POST_CREATED",
          content: title,
          timestamp: new Date()
        };
        
        await storage.createActivity(activityData);
      }
      
      // Başarılı cevap
      res.status(201).json({
        message: "Video başarıyla yüklendi ve işleniyor.",
        contents: createdContents
      });
      
    } catch (error) {
      console.error("Video yükleme hatası:", error);
      res.status(500).json({ 
        message: "Video yüklenirken bir hata oluştu.",
        error: (error as Error).message 
      });
    }
  });

  // Mevcut kullanıcı bilgilerini getir
  app.get("/api/user", async (req, res) => {
    try {
      // Gerçek uygulamada kullanıcı bilgisi oturumdan alınacaktır
      const userId = 1; // Şimdilik demo olarak 1 numaralı kullanıcı
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "Kullanıcı bulunamadı" });
      }
      
      // Don't send password in response
      const { password, ...userData } = user;
      res.json(userData);
    } catch (error) {
      console.error("Kullanıcı bilgileri getirilirken hata:", error);
      res.status(500).json({ 
        message: "Kullanıcı bilgileri getirilirken bir hata oluştu." 
      });
    }
  });
  
  // Abonelik Planları API
  app.get("/api/subscription-plans", async (req, res) => {
    try {
      const plans = await storage.getSubscriptionPlans();
      res.json(plans);
    } catch (error) {
      console.error("Abonelik planları getirilirken hata:", error);
      res.status(500).json({ 
        message: "Abonelik planları getirilirken bir hata oluştu." 
      });
    }
  });
  
  app.post("/api/subscription-plans", async (req, res) => {
    try {
      const planData = req.body;
      const plan = await storage.createSubscriptionPlan(planData);
      res.status(201).json(plan);
    } catch (error) {
      console.error("Abonelik planı oluşturulurken hata:", error);
      res.status(400).json({ 
        message: "Abonelik planı oluşturulurken bir hata oluştu." 
      });
    }
  });
  
  app.patch("/api/subscription-plans/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Geçersiz plan kimliği" });
      }
      
      const planData = req.body;
      const plan = await storage.updateSubscriptionPlan(id, planData);
      
      if (!plan) {
        return res.status(404).json({ message: "Plan bulunamadı" });
      }
      
      res.json(plan);
    } catch (error) {
      console.error("Plan güncellenirken hata:", error);
      res.status(400).json({ 
        message: "Plan güncellenirken bir hata oluştu." 
      });
    }
  });
  
  app.delete("/api/subscription-plans/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Geçersiz plan kimliği" });
      }
      
      const success = await storage.deleteSubscriptionPlan(id);
      
      if (!success) {
        return res.status(404).json({ message: "Plan bulunamadı" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Plan silinirken hata:", error);
      res.status(500).json({ 
        message: "Plan silinirken bir hata oluştu." 
      });
    }
  });
  
  // API Anahtarları API
  app.get("/api/api-keys", async (req, res) => {
    try {
      // Gerçek uygulamada API anahtarları veri tabanından gelecek
      // Şimdilik demo veri döndürelim
      res.json([
        {
          id: 1,
          name: "Gemini AI Anahtarı",
          service: "gemini",
          maskedKey: "********••••••••••••••",
          isActive: true
        },
        {
          id: 2,
          name: "Stripe Ödeme",
          service: "stripe",
          maskedKey: "sk_••••••••••••••",
          isActive: true
        },
        {
          id: 3,
          name: "Instagram API",
          service: "instagram",
          maskedKey: "••••••••••••••",
          isActive: false
        },
        {
          id: 4,
          name: "Instagram Secret",
          service: "instagram_secret",
          maskedKey: "••••••••••••••",
          isActive: false
        },
        {
          id: 5,
          name: "Facebook API",
          service: "facebook",
          maskedKey: "••••••••••••••",
          isActive: false
        },
        {
          id: 6,
          name: "Facebook Secret",
          service: "facebook_secret",
          maskedKey: "••••••••••••••",
          isActive: false
        },
        {
          id: 7,
          name: "Twitter API",
          service: "twitter",
          maskedKey: "••••••••••••••",
          isActive: false
        },
        {
          id: 8,
          name: "Twitter Secret",
          service: "twitter_secret",
          maskedKey: "••••••••••••••",
          isActive: false
        },
        {
          id: 9,
          name: "YouTube API",
          service: "youtube",
          maskedKey: "••••••••••••••",
          isActive: false
        },
        {
          id: 10,
          name: "YouTube Secret",
          service: "youtube_secret",
          maskedKey: "••••••••••••••",
          isActive: false
        },
        {
          id: 11,
          name: "YouTube Refresh Token",
          service: "youtube_refresh",
          maskedKey: "••••••••••••••",
          isActive: false
        },
        {
          id: 12,
          name: "LinkedIn API",
          service: "linkedin",
          maskedKey: "••••••••••••••",
          isActive: false
        },
        {
          id: 13,
          name: "LinkedIn Secret",
          service: "linkedin_secret",
          maskedKey: "••••••••••••••",
          isActive: false
        },
        {
          id: 14,
          name: "TikTok API",
          service: "tiktok",
          maskedKey: "••••••••••••••",
          isActive: false
        },
        {
          id: 15,
          name: "TikTok Secret",
          service: "tiktok_secret",
          maskedKey: "••••••••••••••",
          isActive: false
        }
      ]);
    } catch (error) {
      console.error("API anahtarları getirilirken hata:", error);
      res.status(500).json({ 
        message: "API anahtarları getirilirken bir hata oluştu." 
      });
    }
  });
  
  app.post("/api/api-keys", async (req, res) => {
    try {
      // API anahtarını kaydetme simülasyonu
      const apiKeyData = req.body;
      
      // Gerçek uygulamada veri tabanına kaydedilecek
      // Şimdilik başarılı cevap döndürelim
      res.status(201).json({
        id: Date.now(),
        name: apiKeyData.name,
        service: apiKeyData.service,
        maskedKey: apiKeyData.key.substring(0, 3) + "••••••••••••••",
        isActive: apiKeyData.isActive
      });
    } catch (error) {
      console.error("API anahtarı eklenirken hata:", error);
      res.status(400).json({ 
        message: "API anahtarı eklenirken bir hata oluştu." 
      });
    }
  });
  
  app.patch("/api/api-keys/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Geçersiz API anahtarı kimliği" });
      }
      
      // API anahtarı güncelleme simülasyonu
      const apiKeyData = req.body;
      
      // Gerçek uygulamada veri tabanında güncellenecek
      // Şimdilik başarılı cevap döndürelim
      res.json({
        id: id,
        name: apiKeyData.name,
        service: apiKeyData.service,
        maskedKey: apiKeyData.key && apiKeyData.key.length > 3 
          ? apiKeyData.key.substring(0, 3) + "••••••••••••••" 
          : "••••••••••••••••••",
        isActive: apiKeyData.isActive
      });
    } catch (error) {
      console.error("API anahtarı güncellenirken hata:", error);
      res.status(400).json({ 
        message: "API anahtarı güncellenirken bir hata oluştu." 
      });
    }
  });
  
  app.delete("/api/api-keys/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Geçersiz API anahtarı kimliği" });
      }
      
      // API anahtarı silme simülasyonu
      // Gerçek uygulamada veri tabanından silinecek
      
      res.status(204).send();
    } catch (error) {
      console.error("API anahtarı silinirken hata:", error);
      res.status(500).json({ 
        message: "API anahtarı silinirken bir hata oluştu." 
      });
    }
  });
  
  // Tüm Kullanıcıları Getir (Admin paneli için)
  app.get("/api/users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      
      // Şifreleri çıkar
      const sanitizedUsers = users.map(user => {
        const { password, ...userData } = user;
        return userData;
      });
      
      res.json(sanitizedUsers);
    } catch (error) {
      console.error("Kullanıcılar getirilirken hata:", error);
      res.status(500).json({ 
        message: "Kullanıcılar getirilirken bir hata oluştu." 
      });
    }
  });

  // Yorum Analizi API'leri
  app.get("/api/comments", async (req, res) => {
    try {
      const platform = req.query.platform as string | undefined;
      const socialAccountId = req.query.socialAccountId ? parseInt(req.query.socialAccountId as string) : undefined;
      
      // Gerçek bir uygulamada, veritabanından işlenmemiş yorumlar getirilirdi
      // Şimdilik örnek verileri dönüyoruz
      
      const mockComments = [
        {
          id: 1,
          platform: "instagram",
          socialAccountId: 1,
          commentId: "comment123",
          authorName: "mustafafan42",
          authorId: "user123",
          content: "Ürünlerinizi çok seviyorum, harika bir marka!",
          timestamp: new Date(Date.now() - 3600000),
          likes: 12,
          replyCount: 2,
          parentCommentId: null,
          sentiment: "positive",
          isReplied: true
        },
        {
          id: 2,
          platform: "instagram",
          socialAccountId: 1,
          commentId: "comment124",
          authorName: "sosyal_kelebek",
          authorId: "user124",
          content: "Son reklamınızı beğenmedim, beklediğim gibi değildi.",
          timestamp: new Date(Date.now() - 7200000),
          likes: 3,
          replyCount: 1,
          parentCommentId: null,
          sentiment: "negative",
          isReplied: false
        },
        {
          id: 3,
          platform: "facebook",
          socialAccountId: 2,
          commentId: "comment125",
          authorName: "Ayşe Yılmaz",
          authorId: "user125",
          content: "Ne zaman yeni ürünler gelecek? Sabırsızlanıyorum!",
          timestamp: new Date(Date.now() - 10800000),
          likes: 8,
          replyCount: 0,
          parentCommentId: null,
          sentiment: "neutral",
          isReplied: false
        },
        {
          id: 4,
          platform: "youtube",
          socialAccountId: 3,
          commentId: "comment126",
          authorName: "TechLover",
          authorId: "user126",
          content: "Bu videodaki ürünün özellikleri neler? Daha fazla bilgi verebilir misiniz?",
          timestamp: new Date(Date.now() - 86400000),
          likes: 15,
          replyCount: 3,
          parentCommentId: null,
          sentiment: "neutral",
          isReplied: true
        },
        {
          id: 5,
          platform: "tiktok",
          socialAccountId: 4,
          commentId: "comment127",
          authorName: "genc_fenomen",
          authorId: "user127",
          content: "Hayatımda gördüğüm en güzel içerik! Kesinlikle takip ediyorum sizi.",
          timestamp: new Date(Date.now() - 172800000),
          likes: 56,
          replyCount: 4,
          parentCommentId: null,
          sentiment: "positive",
          isReplied: false
        }
      ];
      
      // Filtreleme işlemleri
      let filteredComments = mockComments;
      
      if (platform) {
        filteredComments = filteredComments.filter(comment => comment.platform === platform);
      }
      
      if (socialAccountId) {
        filteredComments = filteredComments.filter(comment => comment.socialAccountId === socialAccountId);
      }
      
      res.json(filteredComments);
    } catch (error) {
      console.error("Yorumlar getirilirken hata:", error);
      res.status(500).json({ 
        message: "Yorumlar getirilirken bir hata oluştu." 
      });
    }
  });
  
  app.get("/api/comment-analyses", async (req, res) => {
    try {
      // Gerçek bir uygulamada, veritabanından analiz raporları getirilirdi
      // Şimdilik sabit veriler dönüyoruz
      const analyses = await storage.getCommentAnalyses(1);
      res.json(analyses);
    } catch (error) {
      console.error("Yorum analizleri getirilirken hata:", error);
      res.status(500).json({ 
        message: "Yorum analizleri getirilirken bir hata oluştu." 
      });
    }
  });
  
  app.post("/api/comment-analyses", async (req, res) => {
    try {
      const analysisData = req.body;
      const analysis = await storage.createCommentAnalysis({
        socialAccountId: analysisData.socialAccountId,
        platform: analysisData.platform,
        commentIds: analysisData.comments,
        analysisResults: analysisData.results,
        createdAt: new Date()
      });
      
      res.status(201).json(analysis);
    } catch (error) {
      console.error("Yorum analizi kaydedilirken hata:", error);
      res.status(400).json({ 
        message: "Yorum analizi kaydedilirken bir hata oluştu." 
      });
    }
  });
  
  // İçerik Önerisi API'leri
  app.get("/api/content-suggestions", async (req, res) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : 1;
      
      const suggestions = await storage.getContentSuggestions(userId);
      res.json(suggestions);
    } catch (error) {
      console.error("İçerik önerileri getirilirken hata:", error);
      res.status(500).json({ 
        message: "İçerik önerileri getirilirken bir hata oluştu." 
      });
    }
  });
  
  app.post("/api/content-suggestions", async (req, res) => {
    try {
      const suggestionData = req.body;
      const suggestion = await storage.createContentSuggestion({
        userId: suggestionData.userId,
        socialAccountId: suggestionData.socialAccountId,
        platform: suggestionData.platform,
        title: suggestionData.title,
        content: suggestionData.content,
        contentType: suggestionData.contentType,
        imageDescription: suggestionData.imageDescription,
        status: suggestionData.status,
        createdAt: new Date()
      });
      
      res.status(201).json(suggestion);
    } catch (error) {
      console.error("İçerik önerisi kaydedilirken hata:", error);
      res.status(400).json({ 
        message: "İçerik önerisi kaydedilirken bir hata oluştu." 
      });
    }
  });
  
  app.delete("/api/content-suggestions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Geçersiz öneri kimliği" });
      }
      
      const success = await storage.deleteContentSuggestion(id);
      if (!success) {
        return res.status(404).json({ message: "İçerik önerisi bulunamadı" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("İçerik önerisi silinirken hata:", error);
      res.status(500).json({ 
        message: "İçerik önerisi silinirken bir hata oluştu." 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
