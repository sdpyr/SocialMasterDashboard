import { 
  users, type User, type InsertUser,
  socialAccounts, type SocialAccount, type InsertSocialAccount,
  messages, type Message, type InsertMessage,
  activities, type Activity, type InsertActivity,
  keywords, type Keyword, type InsertKeyword,
  analytics, type Analytics, type InsertAnalytics,
  scheduledContent, type ScheduledContent, type InsertScheduledContent,
  subscriptionPlans, type SubscriptionPlan, type InsertSubscriptionPlan,
  systemServices, type SystemService, type InsertSystemService,
  commentAnalysis, type CommentAnalysis, type InsertCommentAnalysis,
  contentSuggestions, type ContentSuggestion, type InsertContentSuggestion
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;

  // Subscription Plan operations
  getSubscriptionPlans(): Promise<SubscriptionPlan[]>;
  getSubscriptionPlan(id: number): Promise<SubscriptionPlan | undefined>;
  createSubscriptionPlan(plan: InsertSubscriptionPlan): Promise<SubscriptionPlan>;
  updateSubscriptionPlan(id: number, data: Partial<InsertSubscriptionPlan>): Promise<SubscriptionPlan | undefined>;
  deleteSubscriptionPlan(id: number): Promise<boolean>;

  // Social Account operations
  getSocialAccounts(userId: number): Promise<SocialAccount[]>;
  getSocialAccount(id: number): Promise<SocialAccount | undefined>;
  createSocialAccount(account: InsertSocialAccount): Promise<SocialAccount>;
  updateSocialAccount(id: number, data: Partial<InsertSocialAccount>): Promise<SocialAccount | undefined>;
  deleteSocialAccount(id: number): Promise<boolean>;

  // Message operations
  getMessages(socialAccountId: number): Promise<Message[]>;
  getUnreadMessageCount(socialAccountId: number): Promise<number>;
  createMessage(message: InsertMessage): Promise<Message>;
  markMessageAsRead(id: number): Promise<boolean>;

  // Activity operations
  getActivities(socialAccountId: number, limit?: number): Promise<Activity[]>;
  getActivitiesByUser(userId: number, limit?: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;

  // Keyword operations
  getKeywords(userId: number): Promise<Keyword[]>;
  getKeywordsByPlatform(userId: number, platform: string): Promise<Keyword[]>;
  createKeyword(keyword: InsertKeyword): Promise<Keyword>;
  updateKeyword(id: number, data: Partial<InsertKeyword>): Promise<Keyword | undefined>;
  deleteKeyword(id: number): Promise<boolean>;

  // Analytics operations
  getAnalytics(socialAccountId: number, startDate: Date, endDate: Date): Promise<Analytics[]>;
  addAnalyticsEntry(entry: InsertAnalytics): Promise<Analytics>;

  // Content scheduling operations
  getScheduledContent(socialAccountId: number): Promise<ScheduledContent[]>;
  createScheduledContent(content: InsertScheduledContent): Promise<ScheduledContent>;
  updateScheduledContent(id: number, data: Partial<InsertScheduledContent>): Promise<ScheduledContent | undefined>;
  deleteScheduledContent(id: number): Promise<boolean>;

  // System service operations
  getSystemServices(): Promise<SystemService[]>;
  getSystemService(id: number): Promise<SystemService | undefined>;
  getSystemServiceByKey(key: string): Promise<SystemService | undefined>;
  createSystemService(service: InsertSystemService): Promise<SystemService>;
  updateSystemService(id: number, data: Partial<SystemService>): Promise<SystemService | undefined>;
  
  // AI Comment Analysis operations
  getCommentAnalyses(socialAccountId: number): Promise<CommentAnalysis[]>;
  getCommentAnalysis(id: number): Promise<CommentAnalysis | undefined>;
  createCommentAnalysis(analysis: InsertCommentAnalysis): Promise<CommentAnalysis>;
  updateCommentAnalysis(id: number, data: Partial<CommentAnalysis>): Promise<CommentAnalysis | undefined>;
  
  // Content Suggestion operations
  getContentSuggestions(userId: number): Promise<ContentSuggestion[]>;
  getContentSuggestion(id: number): Promise<ContentSuggestion | undefined>;
  createContentSuggestion(suggestion: InsertContentSuggestion): Promise<ContentSuggestion>;
  updateContentSuggestion(id: number, data: Partial<ContentSuggestion>): Promise<ContentSuggestion | undefined>;
  deleteContentSuggestion(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private socialAccounts: Map<number, SocialAccount>;
  private messages: Map<number, Message>;
  private activities: Map<number, Activity>;
  private keywords: Map<number, Keyword>;
  private analytics: Map<number, Analytics>;
  private scheduledContents: Map<number, ScheduledContent>;
  private subscriptionPlans: Map<number, SubscriptionPlan>;
  private systemServices: Map<number, SystemService>;
  private commentAnalyses: Map<number, CommentAnalysis>;
  private contentSuggestions: Map<number, ContentSuggestion>;

  private currentUserId: number;
  private currentSocialAccountId: number;
  private currentMessageId: number;
  private currentActivityId: number;
  private currentKeywordId: number;
  private currentAnalyticsId: number;
  private currentScheduledContentId: number;
  private currentSubscriptionPlanId: number;
  private currentSystemServiceId: number;
  private currentCommentAnalysisId: number;
  private currentContentSuggestionId: number;

  constructor() {
    this.users = new Map();
    this.socialAccounts = new Map();
    this.messages = new Map();
    this.activities = new Map();
    this.keywords = new Map();
    this.analytics = new Map();
    this.scheduledContents = new Map();
    this.subscriptionPlans = new Map();

    this.currentUserId = 1;
    this.currentSocialAccountId = 1;
    this.currentMessageId = 1;
    this.currentActivityId = 1;
    this.currentKeywordId = 1;
    this.currentAnalyticsId = 1;
    this.currentScheduledContentId = 1;
    this.currentSubscriptionPlanId = 1;

    // Add initial demo data
    this.initDemoData();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: new Date(),
      role: "user",
      subscriptionTier: "free",
      avatarUrl: insertUser.avatarUrl || null,
      stripeCustomerId: null,
      stripeSubscriptionId: null
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, data: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...data };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }
  
  // Subscription Plan operations
  async getSubscriptionPlans(): Promise<SubscriptionPlan[]> {
    return Array.from(this.subscriptionPlans.values());
  }
  
  async getSubscriptionPlan(id: number): Promise<SubscriptionPlan | undefined> {
    return this.subscriptionPlans.get(id);
  }
  
  async createSubscriptionPlan(plan: InsertSubscriptionPlan): Promise<SubscriptionPlan> {
    const id = this.currentSubscriptionPlanId++;
    const newPlan: SubscriptionPlan = { ...plan, id, createdAt: new Date() };
    this.subscriptionPlans.set(id, newPlan);
    return newPlan;
  }
  
  async updateSubscriptionPlan(id: number, data: Partial<InsertSubscriptionPlan>): Promise<SubscriptionPlan | undefined> {
    const plan = this.subscriptionPlans.get(id);
    if (!plan) return undefined;
    
    const updatedPlan = { ...plan, ...data };
    this.subscriptionPlans.set(id, updatedPlan);
    return updatedPlan;
  }
  
  async deleteSubscriptionPlan(id: number): Promise<boolean> {
    return this.subscriptionPlans.delete(id);
  }

  // Social Account operations
  async getSocialAccounts(userId: number): Promise<SocialAccount[]> {
    return Array.from(this.socialAccounts.values()).filter(
      (account) => account.userId === userId
    );
  }

  async getSocialAccount(id: number): Promise<SocialAccount | undefined> {
    return this.socialAccounts.get(id);
  }

  async createSocialAccount(account: InsertSocialAccount): Promise<SocialAccount> {
    const id = this.currentSocialAccountId++;
    const newAccount: SocialAccount = { ...account, id, createdAt: new Date() };
    this.socialAccounts.set(id, newAccount);
    return newAccount;
  }

  async updateSocialAccount(id: number, data: Partial<InsertSocialAccount>): Promise<SocialAccount | undefined> {
    const account = this.socialAccounts.get(id);
    if (!account) return undefined;

    const updatedAccount = { ...account, ...data };
    this.socialAccounts.set(id, updatedAccount);
    return updatedAccount;
  }

  async deleteSocialAccount(id: number): Promise<boolean> {
    return this.socialAccounts.delete(id);
  }

  // Message operations
  async getMessages(socialAccountId: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter((message) => message.socialAccountId === socialAccountId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async getUnreadMessageCount(socialAccountId: number): Promise<number> {
    return Array.from(this.messages.values()).filter(
      (message) => message.socialAccountId === socialAccountId && !message.isRead
    ).length;
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const id = this.currentMessageId++;
    const newMessage: Message = { ...message, id };
    this.messages.set(id, newMessage);
    return newMessage;
  }

  async markMessageAsRead(id: number): Promise<boolean> {
    const message = this.messages.get(id);
    if (!message) return false;

    message.isRead = true;
    this.messages.set(id, message);
    return true;
  }

  // Activity operations
  async getActivities(socialAccountId: number, limit?: number): Promise<Activity[]> {
    const activities = Array.from(this.activities.values())
      .filter((activity) => activity.socialAccountId === socialAccountId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

    return limit ? activities.slice(0, limit) : activities;
  }

  async getActivitiesByUser(userId: number, limit?: number): Promise<Activity[]> {
    // Get all social accounts for this user
    const userAccounts = Array.from(this.socialAccounts.values())
      .filter(account => account.userId === userId)
      .map(account => account.id);

    // Get activities for all those accounts
    const activities = Array.from(this.activities.values())
      .filter(activity => userAccounts.includes(activity.socialAccountId))
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

    return limit ? activities.slice(0, limit) : activities;
  }

  async createActivity(activity: InsertActivity): Promise<Activity> {
    const id = this.currentActivityId++;
    const newActivity: Activity = { ...activity, id };
    this.activities.set(id, newActivity);
    return newActivity;
  }

  // Keyword operations
  async getKeywords(userId: number): Promise<Keyword[]> {
    return Array.from(this.keywords.values()).filter(
      (keyword) => keyword.userId === userId
    );
  }

  async getKeywordsByPlatform(userId: number, platform: string): Promise<Keyword[]> {
    return Array.from(this.keywords.values()).filter(
      (keyword) => keyword.userId === userId && (keyword.platform === platform || keyword.platform === null)
    );
  }

  async createKeyword(keyword: InsertKeyword): Promise<Keyword> {
    const id = this.currentKeywordId++;
    const newKeyword: Keyword = { ...keyword, id, lastUpdated: new Date() };
    this.keywords.set(id, newKeyword);
    return newKeyword;
  }

  async updateKeyword(id: number, data: Partial<InsertKeyword>): Promise<Keyword | undefined> {
    const keyword = this.keywords.get(id);
    if (!keyword) return undefined;

    const updatedKeyword = { ...keyword, ...data, lastUpdated: new Date() };
    this.keywords.set(id, updatedKeyword);
    return updatedKeyword;
  }

  async deleteKeyword(id: number): Promise<boolean> {
    return this.keywords.delete(id);
  }

  // Analytics operations
  async getAnalytics(socialAccountId: number, startDate: Date, endDate: Date): Promise<Analytics[]> {
    return Array.from(this.analytics.values()).filter(
      (entry) => 
        entry.socialAccountId === socialAccountId && 
        entry.date >= startDate && 
        entry.date <= endDate
    ).sort((a, b) => a.date.getTime() - b.date.getTime());
  }

  async addAnalyticsEntry(entry: InsertAnalytics): Promise<Analytics> {
    const id = this.currentAnalyticsId++;
    const newEntry: Analytics = { ...entry, id };
    this.analytics.set(id, newEntry);
    return newEntry;
  }

  // Content scheduling operations
  async getScheduledContent(socialAccountId: number): Promise<ScheduledContent[]> {
    return Array.from(this.scheduledContents.values())
      .filter((content) => content.socialAccountId === socialAccountId)
      .sort((a, b) => a.scheduledFor.getTime() - b.scheduledFor.getTime());
  }

  async createScheduledContent(content: InsertScheduledContent): Promise<ScheduledContent> {
    const id = this.currentScheduledContentId++;
    const newContent: ScheduledContent = { ...content, id, createdAt: new Date() };
    this.scheduledContents.set(id, newContent);
    return newContent;
  }

  async updateScheduledContent(id: number, data: Partial<InsertScheduledContent>): Promise<ScheduledContent | undefined> {
    const content = this.scheduledContents.get(id);
    if (!content) return undefined;

    const updatedContent = { ...content, ...data };
    this.scheduledContents.set(id, updatedContent);
    return updatedContent;
  }

  async deleteScheduledContent(id: number): Promise<boolean> {
    return this.scheduledContents.delete(id);
  }

  // Initialize with demo data
  private initDemoData() {
    // Create subscription plans
    const subscriptionPlansData: InsertSubscriptionPlan[] = [
      {
        name: "Ücretsiz Plan",
        tier: "free",
        description: "Sosyal medya yönetimi için temel paket",
        price: 0,
        features: ["1 sosyal medya platformu", "Haftalık 1 gönderi", "Temel istatistikler"],
        maxAccounts: 1,
        maxPosts: 1
      },
      {
        name: "Premium Plan",
        tier: "premium",
        description: "Profesyonel sosyal medya yönetimi için",
        price: 2999, // stored in cents (29.99)
        features: ["4 sosyal medya platformu", "Haftalık 10 gönderi", "Detaylı analitikler", "İçerik zamanlaması", "Anahtar kelime takibi"],
        maxAccounts: 4,
        maxPosts: 10
      },
      {
        name: "Ultimate Plan",
        tier: "ultimate",
        description: "Sınırsız sosyal medya yönetimi",
        price: 4999, // stored in cents (49.99)
        features: ["Sınırsız sosyal medya platformu", "Sınırsız gönderi", "Gelişmiş analitikler", "Öncelikli destek", "Özelleştirilebilir raporlar"],
        maxAccounts: -1, // Unlimited
        maxPosts: -1 // Unlimited
      }
    ];
    
    subscriptionPlansData.forEach(plan => {
      this.createSubscriptionPlan(plan);
    });
    
    // Create a demo admin user
    const adminUser: InsertUser = {
      username: "admin",
      password: "admin123",
      email: "admin@example.com",
      fullName: "Admin Kullanıcı"
    };
    const admin = this.createUser(adminUser);
    
    // Update admin to have admin role
    this.updateUser(admin.id, { role: "admin" });
    
    // Create a demo user
    const demoUser: InsertUser = {
      username: "demo",
      password: "password123",
      email: "demo@example.com",
      fullName: "Mehmet Yılmaz"
    };
    const user = this.createUser(demoUser);

    // Create social accounts
    const socialAccountsData: InsertSocialAccount[] = [
      {
        userId: 1,
        name: "AcmeMarka",
        platform: "instagram", 
        accountId: "acme123",
        username: "acmemarka",
        avatarUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
        isActive: true,
        stats: { followers: 54000, posts: 342, engagement: 5.2 }
      },
      {
        userId: 1,
        name: "AcmeMarka",
        platform: "facebook", 
        accountId: "acme456",
        username: "AcmeMarka",
        avatarUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
        isActive: true,
        stats: { followers: 23000, posts: 180, engagement: 3.8 }
      },
      {
        userId: 1,
        name: "AcmeMarka", 
        platform: "youtube",
        accountId: "acme789",
        username: "AcmeMarka",
        avatarUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
        isActive: true,
        stats: { followers: 32000, posts: 78, engagement: 7.5 }
      },
      {
        userId: 1,
        name: "AcmeMarka",
        platform: "tiktok",
        accountId: "acme101",
        username: "acmemarka",
        avatarUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
        isActive: true,
        stats: { followers: 19500, posts: 126, engagement: 9.3 }
      },
      {
        userId: 1,
        name: "TechSoft",
        platform: "instagram",
        accountId: "tech123",
        username: "techsoft",
        avatarUrl: "https://images.unsplash.com/photo-1519244703995-f4e0f30006d5?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
        isActive: false,
        stats: { followers: 12000, posts: 98, engagement: 4.1 }
      },
      {
        userId: 1,
        name: "SeçkinButik",
        platform: "instagram",
        accountId: "butik123",
        username: "seckinbutik",
        avatarUrl: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
        isActive: false,
        stats: { followers: 8500, posts: 212, engagement: 6.7 }
      }
    ];

    socialAccountsData.forEach(account => {
      this.createSocialAccount(account);
    });

    // Create messages
    const messagesData: InsertMessage[] = [
      {
        socialAccountId: 1,
        platform: "instagram",
        senderId: "user123",
        senderName: "Ahmet Yılmaz",
        senderAvatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
        content: "Merhaba, ürünleriniz hakkında bilgi almak istiyorum...",
        timestamp: new Date(),
        isRead: false
      },
      {
        socialAccountId: 1,
        platform: "instagram",
        senderId: "user456",
        senderName: "Ayşe Kaya",
        senderAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
        content: "Son kampanyanız ne zaman başlıyor?",
        timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000), // yesterday
        isRead: false
      },
      {
        socialAccountId: 3,
        platform: "youtube",
        senderId: "user789",
        senderName: "Mehmet Demir",
        senderAvatar: "https://images.unsplash.com/photo-1519244703995-f4e0f30006d5?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
        content: "İş birliği yapmak istiyoruz. Detayları konuşabilir miyiz?",
        timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
        isRead: false
      },
      {
        socialAccountId: 2,
        platform: "facebook",
        senderId: "user101",
        senderName: "Zeynep Yıldız",
        senderAvatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
        content: "Teşekkürler! Geri dönüşünüz için...",
        timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
        isRead: true
      }
    ];

    messagesData.forEach(message => {
      this.createMessage(message);
    });

    // Create activities
    const now = new Date();
    const activitiesData: InsertActivity[] = [
      {
        socialAccountId: 1,
        platform: "instagram",
        activityType: "like",
        actorId: "user123",
        actorName: "@kullanici123",
        actorAvatar: null,
        content: "Instagram gönderinizi beğendi",
        targetUrl: null,
        timestamp: new Date(now.getTime() - 25 * 60 * 1000) // 25 minutes ago
      },
      {
        socialAccountId: 3,
        platform: "youtube",
        activityType: "comment",
        actorId: "user456",
        actorName: "YouTube Kullanıcısı",
        actorAvatar: null,
        content: "Harika içerik, teşekkürler!",
        targetUrl: null,
        timestamp: new Date(now.getTime() - 60 * 60 * 1000) // 1 hour ago
      },
      {
        socialAccountId: 2,
        platform: "facebook",
        activityType: "follow",
        actorId: null,
        actorName: null,
        actorAvatar: null,
        content: "Facebook sayfanız 50 yeni takipçi kazandı",
        targetUrl: null,
        timestamp: new Date(now.getTime() - 3 * 60 * 60 * 1000) // 3 hours ago
      },
      {
        socialAccountId: 4,
        platform: "tiktok",
        activityType: "view",
        actorId: null,
        actorName: null,
        actorAvatar: null,
        content: "TikTok videonuz 10K görüntülenme eşiğini aştı",
        targetUrl: null,
        timestamp: new Date(now.getTime() - 5 * 60 * 60 * 1000) // 5 hours ago
      },
      {
        socialAccountId: 1,
        platform: "instagram",
        activityType: "engagement",
        actorId: null,
        actorName: null,
        actorAvatar: null,
        content: "Instagram hikayeniz yüksek etkileşim alıyor",
        targetUrl: null,
        timestamp: new Date(now.getTime() - 6 * 60 * 60 * 1000) // 6 hours ago
      }
    ];

    activitiesData.forEach(activity => {
      this.createActivity(activity);
    });

    // Create keywords
    const keywordsData: InsertKeyword[] = [
      {
        userId: 1,
        socialAccountId: 1,
        platform: "instagram",
        keyword: "#AcmeMarka",
        mentions: 3245,
        changePercentage: 18,
        sentiment: 75,
        lastUpdated: new Date(now.getTime() - 60 * 60 * 1000) // 1 hour ago
      },
      {
        userId: 1,
        socialAccountId: 3,
        platform: "youtube",
        keyword: "#YeniÜrün",
        mentions: 1876,
        changePercentage: 32,
        sentiment: 82,
        lastUpdated: new Date(now.getTime() - 3 * 60 * 60 * 1000) // 3 hours ago
      },
      {
        userId: 1,
        socialAccountId: 2,
        platform: "facebook",
        keyword: "Müşteri Hizmetleri",
        mentions: 924,
        changePercentage: -5,
        sentiment: 45,
        lastUpdated: new Date(now.getTime() - 6 * 60 * 60 * 1000) // 6 hours ago
      },
      {
        userId: 1,
        socialAccountId: 4,
        platform: "tiktok",
        keyword: "Ürün İncelemesi",
        mentions: 2185,
        changePercentage: 45,
        sentiment: 68,
        lastUpdated: new Date(now.getTime() - 12 * 60 * 60 * 1000) // 12 hours ago
      }
    ];

    keywordsData.forEach(keyword => {
      this.createKeyword(keyword);
    });

    // Create analytics entries for the past week
    const platforms = ["instagram", "youtube", "facebook", "tiktok"];
    const pastDays = 7;
    
    for (let accountId = 1; accountId <= 4; accountId++) {
      const platform = platforms[accountId - 1];
      
      for (let day = 0; day < pastDays; day++) {
        const date = new Date();
        date.setDate(date.getDate() - day);
        
        // Create random but increasing data
        const baseFollowers = 10000 + accountId * 5000;
        const followers = baseFollowers + (pastDays - day) * 100;
        
        const entry: InsertAnalytics = {
          socialAccountId: accountId,
          platform,
          date,
          followers,
          engagement: Math.floor(Math.random() * 1000) + 500,
          impressions: Math.floor(Math.random() * 10000) + 5000,
          likes: Math.floor(Math.random() * 500) + 100,
          comments: Math.floor(Math.random() * 100) + 20,
          shares: Math.floor(Math.random() * 50) + 10,
          views: Math.floor(Math.random() * 3000) + 1000
        };
        
        this.addAnalyticsEntry(entry);
      }
    }

    // Create scheduled content
    const future = new Date();
    future.setDate(future.getDate() + 2);
    
    const scheduledContentData: InsertScheduledContent[] = [
      {
        socialAccountId: 1,
        platform: "instagram",
        content: "Yeni ürün koleksiyonumuz yarın satışta! #YeniKoleksiyon #AcmeMarka",
        mediaUrls: ["/images/product1.jpg", "/images/product2.jpg"],
        scheduledFor: future,
        status: "pending"
      },
      {
        socialAccountId: 3,
        platform: "youtube",
        content: "Ürün inceleme videomuz için link bio'da!",
        mediaUrls: ["/videos/product-review.mp4"],
        scheduledFor: new Date(future.getTime() + 24 * 60 * 60 * 1000), // day after
        status: "pending"
      }
    ];

    scheduledContentData.forEach(content => {
      this.createScheduledContent(content);
    });
  }
}

export const storage = new MemStorage();
