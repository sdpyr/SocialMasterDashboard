import { Request, Response } from "express";
import { storage } from "../storage";
import { insertScheduledContentSchema } from "@shared/schema";
import { z } from "zod";

// Using the same demo user ID from constants.ts in the client
const DEMO_USER_ID = 1;

export default async function registerContentRoutes(app: any) {
  // Get all scheduled content for a user
  app.get("/api/content", async (req: Request, res: Response) => {
    try {
      const socialAccountId = parseInt(req.query.socialAccountId as string) || 0;
      
      let content;
      if (socialAccountId > 0) {
        content = await storage.getScheduledContent(socialAccountId);
      } else {
        // For demo purposes we'll get content for all accounts of the demo user
        const accounts = await storage.getSocialAccounts(DEMO_USER_ID);
        content = [];
        
        for (const account of accounts) {
          const accountContent = await storage.getScheduledContent(account.id);
          content.push(...accountContent);
        }
      }
      
      res.json(content);
    } catch (error) {
      console.error("Error fetching content:", error);
      res.status(500).json({ error: "Failed to fetch content" });
    }
  });
  
  // Post a new content or schedule one
  app.post("/api/content", async (req: Request, res: Response) => {
    try {
      // Create a custom schema for content creation that extends the insert schema
      const contentCreateSchema = insertScheduledContentSchema.extend({
        mediaUrls: z.array(z.string()).optional(),
      });
      
      const result = contentCreateSchema.safeParse(req.body);
      
      if (!result.success) {
        console.error("Validation error:", result.error);
        return res.status(400).json({ 
          error: "Validation error", 
          details: result.error.format() 
        });
      }
      
      const contentData = result.data;
      
      // Create the content in storage
      const newContent = await storage.createScheduledContent({
        ...contentData,
        createdAt: new Date()
      });
      
      // Add an activity record for content creation
      await storage.createActivity({
        socialAccountId: contentData.socialAccountId,
        type: contentData.status === 'pending' ? 'content_scheduled' : 'content_posted',
        timestamp: new Date(),
        data: {
          contentId: newContent.id,
          platform: contentData.platform
        }
      });
      
      res.status(201).json(newContent);
    } catch (error) {
      console.error("Error creating content:", error);
      res.status(500).json({ error: "Failed to create content" });
    }
  });
  
  // Update a content
  app.patch("/api/content/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      const updateSchema = insertScheduledContentSchema.partial().extend({
        mediaUrls: z.array(z.string()).optional(),
      });
      
      const result = updateSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          error: "Validation error", 
          details: result.error.format() 
        });
      }
      
      const contentData = result.data;
      
      const updatedContent = await storage.updateScheduledContent(id, contentData);
      
      if (!updatedContent) {
        return res.status(404).json({ error: "Content not found" });
      }
      
      res.json(updatedContent);
    } catch (error) {
      console.error("Error updating content:", error);
      res.status(500).json({ error: "Failed to update content" });
    }
  });
  
  // Delete a content
  app.delete("/api/content/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      const success = await storage.deleteScheduledContent(id);
      
      if (!success) {
        return res.status(404).json({ error: "Content not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting content:", error);
      res.status(500).json({ error: "Failed to delete content" });
    }
  });
}