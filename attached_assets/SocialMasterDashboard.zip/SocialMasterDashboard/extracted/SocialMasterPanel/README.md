# CrossPostHub - Sosyal Medya Yönetim Paneli

CrossPostHub, birden fazla sosyal medya platformunu tek bir yerden yönetmenizi sağlayan modern bir sosyal medya yönetim panelidir. Flat 2.0 tasarım dili ile geliştirilmiş olan bu platform, Instagram, YouTube, TikTok, Facebook, Twitter ve LinkedIn gibi popüler sosyal medya platformlarında içerik yönetimini kolaylaştırır.

![CrossPostHub Dashboard](client/public/crossposthub-dashboard.png)

## Özellikler

- Çoklu platform desteği (Instagram, YouTube, TikTok, Facebook, Twitter, LinkedIn)
- İçerik oluşturma, planlama ve çoklu platformda paylaşma
- Detaylı analitik ve istatistikler
- Mesaj yönetimi ve takibi
- Anahtar kelime izleme ve analizi
- Kullanıcı ve abonelik planı yönetimi
- AI destekli içerik önerileri ve yorum analizi
- Çok dilli arayüz (Türkçe/İngilizce)

## Sistem Gereksinimleri

- Node.js 18.x veya üzeri
- PostgreSQL 14.x veya üzeri
- Internet bağlantısı (API entegrasyonları için)
- Minimum 1GB RAM
- 1GB disk alanı

## Teknoloji Yığını

- **Backend**: Node.js, Express.js, Drizzle ORM
- **Frontend**: React, TypeScript, TailwindCSS, ShadCN UI
- **Veritabanı**: PostgreSQL
- **AI Entegrasyonları**: Google Gemini API

## Kurulum

### Gerekli Paketlerin Yüklenmesi

```bash
npm install
```

### Veritabanı Kurulumu

PostgreSQL veritabanınızı hazırladıktan sonra, `.env` dosyasında veritabanı bağlantı bilgilerinizi belirtin:

```
DATABASE_URL=postgresql://kullanici:sifre@localhost:5432/crossposthub
```

Veritabanı şema değişikliklerini uygulamak için:

```bash
npm run db:push
```

### API Anahtarları

Yapay zeka özellikleri için bir Google Gemini API anahtarı gereklidir. API anahtarını `.env` dosyasına ekleyin:

```
GEMINI_API_KEY=your_api_key_here
```

### Uygulamayı Başlatma

Geliştirme modunda başlatmak için:

```bash
npm run dev
```

Uygulama varsayılan olarak `http://localhost:3000` adresinde çalışacaktır.

## Abonelik Planları

CrossPostHub üç farklı abonelik planı sunmaktadır:

1. **Ücretsiz Plan**
   - 1 sosyal medya hesabı
   - Haftalık 1 gönderi
   - Temel istatistikler

2. **Premium Plan**
   - 4 sosyal medya hesabı
   - Haftalık 10 gönderi
   - Detaylı analitikler
   - İçerik zamanlaması
   - Anahtar kelime takibi

3. **Ultimate Plan**
   - Sınırsız sosyal medya hesabı
   - Sınırsız gönderi
   - Gelişmiş analitikler
   - Öncelikli destek
   - Özelleştirilebilir raporlar
   - Tüm AI özellikleri

## Katkıda Bulunma

Projeye katkıda bulunmak istiyorsanız, bir fork oluşturun ve pull request gönderin.

## Lisans

CrossPostHub ticari bir üründür ve lisans şartları için doğrudan iletişime geçin.

---

# CrossPostHub - Social Media Management Panel

CrossPostHub is a modern social media management panel that allows you to manage multiple social media platforms from a single location. Developed with Flat 2.0 design language, this platform simplifies content management on popular social media platforms such as Instagram, YouTube, TikTok, Facebook, Twitter, and LinkedIn.

![CrossPostHub Dashboard](client/public/crossposthub-dashboard.png)

## Features

- Multi-platform support (Instagram, YouTube, TikTok, Facebook, Twitter, LinkedIn)
- Content creation, scheduling, and sharing across multiple platforms
- Detailed analytics and statistics
- Message management and tracking
- Keyword monitoring and analysis
- User and subscription plan management
- AI-powered content suggestions and comment analysis
- Multilingual interface (Turkish/English)

## System Requirements

- Node.js 18.x or higher
- PostgreSQL 14.x or higher
- Internet connection (for API integrations)
- Minimum 1GB RAM
- 1GB disk space

## Technology Stack

- **Backend**: Node.js, Express.js, Drizzle ORM
- **Frontend**: React, TypeScript, TailwindCSS, ShadCN UI
- **Database**: PostgreSQL
- **AI Integrations**: Google Gemini API

## Installation

### Installing Required Packages

```bash
npm install
```

### Database Setup

After preparing your PostgreSQL database, specify your database connection information in the `.env` file:

```
DATABASE_URL=postgresql://user:password@localhost:5432/crossposthub
```

To apply database schema changes:

```bash
npm run db:push
```

### API Keys

A Google Gemini API key is required for artificial intelligence features. Add the API key to your `.env` file:

```
GEMINI_API_KEY=your_api_key_here
```

### Starting the Application

To start in development mode:

```bash
npm run dev
```

The application will run at `http://localhost:3000` by default.

## Subscription Plans

CrossPostHub offers three different subscription plans:

1. **Free Plan**
   - 1 social media account
   - 1 post per week
   - Basic statistics

2. **Premium Plan**
   - 4 social media accounts
   - 10 posts per week
   - Detailed analytics
   - Content scheduling
   - Keyword tracking

3. **Ultimate Plan**
   - Unlimited social media accounts
   - Unlimited posts
   - Advanced analytics
   - Priority support
   - Customizable reports
   - All AI features

## Contributing

If you want to contribute to the project, create a fork and submit a pull request.

## License

CrossPostHub is a commercial product, please contact directly for licensing terms.