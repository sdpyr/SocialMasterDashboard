import { pgTable, text, serial, integer, boolean, timestamp, json, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Define platform enum for type safety
export const PlatformEnum = z.enum(["instagram", "youtube", "tiktok", "facebook", "twitter", "linkedin"]);
export type Platform = z.infer<typeof PlatformEnum>;

// User role enum for authorization
export const roleEnum = pgEnum("role", ["user", "admin"]);

// Subscription tier enum
export const subscriptionTierEnum = pgEnum("subscription_tier", ["free", "premium", "ultimate"]);

// AI feature types enum
export const aiFeatureTypeEnum = pgEnum("ai_feature_type", [
  "comment_analysis", 
  "auto_response", 
  "content_suggestion", 
  "sentiment_analysis",
  "engagement_prediction"
]);

// Service status enum
export const serviceStatusEnum = pgEnum("service_status", ["active", "maintenance", "disabled"]);

// System service status management
export const systemServices = pgTable("system_services", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  key: text("key").notNull().unique(),
  description: text("description").notNull(),
  status: serviceStatusEnum("status").default("active").notNull(),
  isCore: boolean("is_core").default(false).notNull(), // Core services cannot be disabled
  lastStatusChange: timestamp("last_status_change").defaultNow().notNull(),
  icon: text("icon").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertSystemServiceSchema = createInsertSchema(systemServices).omit({ id: true, createdAt: true, lastStatusChange: true });
export type InsertSystemService = z.infer<typeof insertSystemServiceSchema>;
export type SystemService = typeof systemServices.$inferSelect;

// AI comment analysis
export const commentAnalysis = pgTable("comment_analysis", {
  id: serial("id").primaryKey(),
  socialAccountId: integer("social_account_id").notNull().references(() => socialAccounts.id),
  platform: text("platform").notNull(),
  commentId: text("comment_id").notNull(),
  commentText: text("comment_text").notNull(),
  commentAuthor: text("comment_author").notNull(),
  sentiment: integer("sentiment").notNull(), // 0-100 scale
  topics: text("topics").array(),
  suggestedResponse: text("suggested_response"),
  isResponded: boolean("is_responded").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertCommentAnalysisSchema = createInsertSchema(commentAnalysis).omit({ id: true, createdAt: true });
export type InsertCommentAnalysis = z.infer<typeof insertCommentAnalysisSchema>;
export type CommentAnalysis = typeof commentAnalysis.$inferSelect;

// AI content suggestions
export const contentSuggestions = pgTable("content_suggestions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  socialAccountId: integer("social_account_id").references(() => socialAccounts.id),
  platform: text("platform"),
  title: text("title").notNull(),
  content: text("content").notNull(),
  topics: text("topics").array(),
  status: text("status").default("pending").notNull(), // pending, approved, rejected, published
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertContentSuggestionSchema = createInsertSchema(contentSuggestions).omit({ id: true, createdAt: true });
export type InsertContentSuggestion = z.infer<typeof insertContentSuggestionSchema>;
export type ContentSuggestion = typeof contentSuggestions.$inferSelect;

// Subscription Plans with detailed features
export const subscriptionPlans = pgTable("subscription_plans", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  tier: subscriptionTierEnum("tier").notNull(),
  price: integer("price").notNull(), // in cents
  features: text("features").array(),
  maxAccounts: integer("max_accounts").notNull(),
  maxPosts: integer("max_posts").notNull(), // posts per week
  description: text("description").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  // Detailed feature flags
  hasAnalytics: boolean("has_analytics").default(false).notNull(),
  hasScheduling: boolean("has_scheduling").default(false).notNull(),
  hasKeywordTracking: boolean("has_keyword_tracking").default(false).notNull(),
  hasAiFeatures: boolean("has_ai_features").default(false).notNull(),
  hasMultiPlatform: boolean("has_multi_platform").default(false).notNull(),
  hasTeamCollaboration: boolean("has_team_collaboration").default(false).notNull(),
  hasPrioritySupport: boolean("has_priority_support").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertSubscriptionPlanSchema = createInsertSchema(subscriptionPlans).omit({ id: true, createdAt: true });
export type InsertSubscriptionPlan = z.infer<typeof insertSubscriptionPlanSchema>;
export type SubscriptionPlan = typeof subscriptionPlans.$inferSelect;

// User accounts
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull(),
  fullName: text("full_name").notNull(),
  avatarUrl: text("avatar_url"),
  role: roleEnum("role").default("user").notNull(),
  subscriptionTier: subscriptionTierEnum("subscription_tier").default("free").notNull(),
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true, role: true, subscriptionTier: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Social media accounts
export const socialAccounts = pgTable("social_accounts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  platform: text("platform").notNull(), // instagram, youtube, tiktok, facebook
  accountId: text("account_id").notNull(),
  username: text("username").notNull(),
  avatarUrl: text("avatar_url"),
  isActive: boolean("is_active").default(true).notNull(),
  stats: json("stats").$type<{ followers: number, posts: number, engagement: number }>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertSocialAccountSchema = createInsertSchema(socialAccounts).omit({ id: true, createdAt: true });
export type InsertSocialAccount = z.infer<typeof insertSocialAccountSchema>;
export type SocialAccount = typeof socialAccounts.$inferSelect;

// Messages 
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  socialAccountId: integer("social_account_id").notNull().references(() => socialAccounts.id),
  platform: text("platform").notNull(), // instagram, youtube, tiktok, facebook
  senderId: text("sender_id").notNull(),
  senderName: text("sender_name").notNull(),
  senderAvatar: text("sender_avatar"),
  content: text("content").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  isRead: boolean("is_read").default(false).notNull(),
});

export const insertMessageSchema = createInsertSchema(messages).omit({ id: true });
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;

// Activities
export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  socialAccountId: integer("social_account_id").notNull().references(() => socialAccounts.id),
  platform: text("platform").notNull(), // instagram, youtube, tiktok, facebook
  activityType: text("activity_type").notNull(), // like, comment, follow, mention, share
  actorId: text("actor_id"),
  actorName: text("actor_name"),
  actorAvatar: text("actor_avatar"),
  content: text("content"),
  targetUrl: text("target_url"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertActivitySchema = createInsertSchema(activities).omit({ id: true });
export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activities.$inferSelect;

// Keywords to track
export const keywords = pgTable("keywords", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  socialAccountId: integer("social_account_id").references(() => socialAccounts.id),
  platform: text("platform"), // if null, track across all platforms
  keyword: text("keyword").notNull(),
  mentions: integer("mentions").default(0).notNull(),
  changePercentage: integer("change_percentage").default(0),
  sentiment: integer("sentiment").default(50), // 0-100 scale
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

export const insertKeywordSchema = createInsertSchema(keywords).omit({ id: true, lastUpdated: true });
export type InsertKeyword = z.infer<typeof insertKeywordSchema>;
export type Keyword = typeof keywords.$inferSelect;

// Analytics data
export const analytics = pgTable("analytics", {
  id: serial("id").primaryKey(),
  socialAccountId: integer("social_account_id").notNull().references(() => socialAccounts.id),
  platform: text("platform").notNull(),
  date: timestamp("date").defaultNow().notNull(),
  followers: integer("followers").default(0).notNull(),
  engagement: integer("engagement").default(0).notNull(),
  impressions: integer("impressions").default(0).notNull(),
  likes: integer("likes").default(0),
  comments: integer("comments").default(0),
  shares: integer("shares").default(0),
  views: integer("views").default(0),
});

export const insertAnalyticsSchema = createInsertSchema(analytics).omit({ id: true });
export type InsertAnalytics = z.infer<typeof insertAnalyticsSchema>;
export type Analytics = typeof analytics.$inferSelect;

// Content scheduling
export const scheduledContent = pgTable("scheduled_content", {
  id: serial("id").primaryKey(),
  socialAccountId: integer("social_account_id").notNull().references(() => socialAccounts.id),
  platform: text("platform").notNull(),
  content: text("content").notNull(),
  mediaUrls: json("media_urls").$type<string[]>(),
  scheduledFor: timestamp("scheduled_for").notNull(),
  status: text("status").default("pending").notNull(), // pending, published, failed
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertScheduledContentSchema = createInsertSchema(scheduledContent).omit({ id: true, createdAt: true });
export type InsertScheduledContent = z.infer<typeof insertScheduledContentSchema>;
export type ScheduledContent = typeof scheduledContent.$inferSelect;
