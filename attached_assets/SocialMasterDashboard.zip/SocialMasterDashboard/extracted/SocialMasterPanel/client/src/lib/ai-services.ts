// AI servisleri için merkezi modül
import { 
  generateText, 
  generateSocialMediaContent, 
  generateCompleteContent 
} from './gemini-service';
import { Language } from '../i18n';

/**
 * Yorum analizi yapar
 * @param comments Analiz edilecek yorumlar array'i
 * @param language Dil tercihi
 * @returns Yorum analizi sonuçları
 */
export async function analyzeComments(
  comments: string[], 
  language: Language = 'tr'
): Promise<{
  sentiment: {
    positive: number;
    negative: number;
    neutral: number;
  };
  topTopics: string[];
  recommendedActions: string[];
  summary: string;
}> {
  try {
    const prompt = language === 'tr' 
      ? `Aşağıdaki sosyal medya yorumlarını analiz et ve şu bilgileri JSON formatında döndür:
        1. "sentiment": Duygusal analiz (pozitif, negatif, nötr yorumların yüzdesel dağılımı)
        2. "topTopics": En çok bahsedilen 3-5 konu
        3. "recommendedActions": Alınabilecek 2-3 aksiyon önerisi
        4. "summary": Kısa bir özet (maksimum 100 kelime)
        
        JSON formatında cevap ver. Başka açıklama ekleme.
        
        Yorumlar:
        ${comments.join('\n')}` 
      : `Analyze the following social media comments and return the following information in JSON format:
        1. "sentiment": Sentiment analysis (percentage distribution of positive, negative, neutral comments)
        2. "topTopics": 3-5 most mentioned topics
        3. "recommendedActions": 2-3 recommended actions to take
        4. "summary": A short summary (maximum 100 words)
        
        Answer in JSON format. Do not add any other explanations.
        
        Comments:
        ${comments.join('\n')}`;

    const result = await generateText(prompt);
    
    try {
      // JSON yanıtını parse et
      const parsedResult = JSON.parse(result);
      return {
        sentiment: parsedResult.sentiment || { positive: 33, negative: 33, neutral: 34 },
        topTopics: parsedResult.topTopics || [],
        recommendedActions: parsedResult.recommendedActions || [],
        summary: parsedResult.summary || ''
      };
    } catch (parseError) {
      console.error('JSON parse hatası:', parseError);
      // Fallback değerler
      return {
        sentiment: { positive: 33, negative: 33, neutral: 34 },
        topTopics: ['Konu 1', 'Konu 2', 'Konu 3'],
        recommendedActions: ['Öneri 1', 'Öneri 2'],
        summary: 'Analiz edilemedi.'
      };
    }
  } catch (error) {
    console.error('Yorum analiz hatası:', error);
    throw new Error(`Yorum analizi yapılamadı: ${error}`);
  }
}

/**
 * Otomatik yanıt önerileri oluşturur
 * @param comment Cevaplanacak yorum
 * @param brandTone Marka tonu (professional, friendly, casual, vb.)
 * @param language Dil tercihi
 * @returns Yanıt önerileri
 */
export async function generateAutoResponses(
  comment: string,
  brandTone: string = 'professional',
  language: Language = 'tr'
): Promise<string[]> {
  try {
    const prompt = language === 'tr'
      ? `Bu sosyal medya yorumuna, ${brandTone} bir tonda 3 farklı cevap önerisi oluştur. 
        Yanıtlar kısa, nazik ve yapıcı olmalı. Her yanıt en fazla 2 cümle olsun.
        Cevapları JSON formatında bir dizi olarak döndür. Başka açıklama ekleme.
        
        Yorum: "${comment}"`
      : `Generate 3 different response suggestions to this social media comment in a ${brandTone} tone.
        Responses should be short, polite, and constructive. Each response should be maximum 2 sentences.
        Return the responses as a JSON array. Do not add any other explanations.
        
        Comment: "${comment}"`;

    const result = await generateText(prompt);
    
    try {
      // JSON yanıtını parse et
      const parsedResult = JSON.parse(result);
      return Array.isArray(parsedResult) ? parsedResult : [result];
    } catch (parseError) {
      // Düz metin olarak döndür
      return [result];
    }
  } catch (error) {
    console.error('Otomatik yanıt oluşturma hatası:', error);
    throw new Error(`Otomatik yanıt oluşturulamadı: ${error}`);
  }
}

/**
 * İçerik önerileri oluşturur
 * @param topics Konu başlıkları
 * @param platforms Hedef platformlar
 * @param language Dil tercihi
 * @returns İçerik önerileri
 */
export async function generateContentIdeas(
  topics: string[],
  platforms: string[],
  language: Language = 'tr'
): Promise<Array<{
  title: string;
  description: string;
  platform: string;
  contentType: string;
  estimatedEngagement: string;
}>> {
  try {
    const prompt = language === 'tr'
      ? `Aşağıdaki konular ve platformlar için içerik fikirleri oluştur.
        Her fikir için şunları içeren bir JSON dizisi döndür:
        1. "title": Başlık
        2. "description": Kısa açıklama
        3. "platform": Uygun platform (${platforms.join(', ')})
        4. "contentType": İçerik türü (video, resim, metin, carousel, vb.)
        5. "estimatedEngagement": Tahmini etkileşim düzeyi (düşük, orta, yüksek)
        
        En az 5 farklı içerik fikri oluştur. Sadece JSON formatında cevap ver.
        
        Konular: ${topics.join(', ')}`
      : `Generate content ideas for the following topics and platforms.
        Return a JSON array with each idea containing:
        1. "title": Title
        2. "description": Short description
        3. "platform": Suitable platform (${platforms.join(', ')})
        4. "contentType": Content type (video, image, text, carousel, etc.)
        5. "estimatedEngagement": Estimated engagement level (low, medium, high)
        
        Generate at least 5 different content ideas. Answer only in JSON format.
        
        Topics: ${topics.join(', ')}`;

    const result = await generateText(prompt);
    
    try {
      // JSON yanıtını parse et
      const parsedResult = JSON.parse(result);
      return Array.isArray(parsedResult) ? parsedResult : [];
    } catch (parseError) {
      console.error('İçerik önerileri JSON parse hatası:', parseError);
      return [];
    }
  } catch (error) {
    console.error('İçerik önerileri oluşturma hatası:', error);
    throw new Error(`İçerik önerileri oluşturulamadı: ${error}`);
  }
}

/**
 * İçerik takvimi önerileri oluşturur
 * @param topics Konu başlıkları
 * @param platform Hedef platform
 * @param duration Süre (gün)
 * @param language Dil tercihi
 * @returns İçerik takvimi
 */
export async function generateContentCalendar(
  topics: string[],
  platform: string,
  duration: number = 7,
  language: Language = 'tr'
): Promise<Array<{
  date: string;
  title: string;
  contentType: string;
  description: string;
  topics: string[];
  bestTimeToPost: string;
}>> {
  try {
    const prompt = language === 'tr'
      ? `${platform} platformu için ${duration} günlük bir içerik takvimi oluştur.
        Her gün için şunları içeren bir JSON dizisi döndür:
        1. "date": Tarih (YYYY-MM-DD formatında)
        2. "title": İçerik başlığı
        3. "contentType": İçerik türü
        4. "description": Kısa açıklama
        5. "topics": İlgili konular
        6. "bestTimeToPost": Gönderinin en iyi yayınlanma saati
        
        Aşağıdaki konuları/temaları her gün değiştirerek kullan. Sadece JSON dizisi olarak cevap ver.
        
        Konular: ${topics.join(', ')}`
      : `Create a ${duration}-day content calendar for ${platform} platform.
        Return a JSON array with each day containing:
        1. "date": Date (in YYYY-MM-DD format)
        2. "title": Content title
        3. "contentType": Content type
        4. "description": Short description
        5. "topics": Related topics
        6. "bestTimeToPost": Best time to post
        
        Use the following topics/themes, rotating them each day. Answer only as a JSON array.
        
        Topics: ${topics.join(', ')}`;

    const result = await generateText(prompt);
    
    try {
      // JSON yanıtını parse et
      const parsedResult = JSON.parse(result);
      return Array.isArray(parsedResult) ? parsedResult : [];
    } catch (parseError) {
      console.error('İçerik takvimi JSON parse hatası:', parseError);
      return [];
    }
  } catch (error) {
    console.error('İçerik takvimi oluşturma hatası:', error);
    throw new Error(`İçerik takvimi oluşturulamadı: ${error}`);
  }
}

/**
 * Performans raporu ve öneriler oluşturur
 * @param stats İstatistikler
 * @param language Dil tercihi
 * @returns Performans raporu ve öneriler
 */
export async function generatePerformanceInsights(
  stats: {
    platform: string;
    followers: number;
    engagement: number;
    posts: number;
    likes: number;
    comments: number;
    shares: number;
    views: number;
    growth: number;
  },
  language: Language = 'tr'
): Promise<{
  summary: string;
  strengths: string[];
  weaknesses: string[];
  opportunities: string[];
  recommendations: string[];
}> {
  try {
    const prompt = language === 'tr'
      ? `Aşağıdaki sosyal medya istatistiklerini analiz et ve performans raporu oluştur.
        Raporu JSON formatında şu yapıda döndür:
        1. "summary": Genel performans özeti (100 kelime)
        2. "strengths": 3 güçlü yön
        3. "weaknesses": 3 zayıf yön
        4. "opportunities": 3 fırsat
        5. "recommendations": 5 öneri
        
        Sadece JSON formatında cevap ver.
        
        İstatistikler:
        Platform: ${stats.platform}
        Takipçi: ${stats.followers}
        Etkileşim Oranı: ${stats.engagement}%
        Gönderi Sayısı: ${stats.posts}
        Beğeni: ${stats.likes}
        Yorum: ${stats.comments}
        Paylaşım: ${stats.shares}
        Görüntüleme: ${stats.views}
        Büyüme: ${stats.growth}%`
      : `Analyze the following social media statistics and create a performance report.
        Return the report in JSON format with the following structure:
        1. "summary": General performance summary (100 words)
        2. "strengths": 3 strengths
        3. "weaknesses": 3 weaknesses
        4. "opportunities": 3 opportunities
        5. "recommendations": 5 recommendations
        
        Answer only in JSON format.
        
        Statistics:
        Platform: ${stats.platform}
        Followers: ${stats.followers}
        Engagement Rate: ${stats.engagement}%
        Posts: ${stats.posts}
        Likes: ${stats.likes}
        Comments: ${stats.comments}
        Shares: ${stats.shares}
        Views: ${stats.views}
        Growth: ${stats.growth}%`;

    const result = await generateText(prompt);
    
    try {
      // JSON yanıtını parse et
      const parsedResult = JSON.parse(result);
      return {
        summary: parsedResult.summary || '',
        strengths: parsedResult.strengths || [],
        weaknesses: parsedResult.weaknesses || [],
        opportunities: parsedResult.opportunities || [],
        recommendations: parsedResult.recommendations || []
      };
    } catch (parseError) {
      console.error('Performans raporu JSON parse hatası:', parseError);
      return {
        summary: '',
        strengths: [],
        weaknesses: [],
        opportunities: [],
        recommendations: []
      };
    }
  } catch (error) {
    console.error('Performans raporu oluşturma hatası:', error);
    throw new Error(`Performans raporu oluşturulamadı: ${error}`);
  }
}

// İçerik oluşturma fonksiyonlarını dışa aktar
export { generateSocialMediaContent, generateCompleteContent };