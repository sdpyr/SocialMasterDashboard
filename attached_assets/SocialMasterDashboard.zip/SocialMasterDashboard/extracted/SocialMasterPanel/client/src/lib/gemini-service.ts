import { GoogleGenerativeAI, HarmBlockThreshold, HarmCategory } from "@google/generative-ai";

// API anahtarını çevre değişkenlerinden alıyoruz
const API_KEY = import.meta.env.VITE_GEMINI_API_KEY || process.env.GEMINI_API_KEY;
let genAI: any;

// API anahtarı varsa gerçek API'yi kullan, yoksa mock değerler kullan
if (API_KEY) {
  genAI = new GoogleGenerativeAI(API_KEY);
} else {
  console.warn("Gemini API anahtarı bulunamadı. Mock değerler kullanılıyor.");
  genAI = {
    getGenerativeModel: () => ({
      generateContent: async () => ({
        response: {
          text: () => "Gemini API anahtarı gerekiyor. Lütfen ayarlardan API anahtarınızı ekleyin."
        }
      })
    })
  };
}

// Model kimlikleri
const TEXT_MODEL = "gemini-1.5-pro-latest";
const MULTIMODAL_MODEL = "gemini-1.5-pro-latest";

// Güvenlik ayarları
const safetySettings = [
  {
    category: HarmCategory.HARM_CATEGORY_HARASSMENT,
    threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
  },
  {
    category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
    threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
  },
  {
    category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
    threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
  },
  {
    category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
    threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
  },
];

/**
 * Metinsel içerik oluşturur
 * @param prompt Metin oluşturmak için kullanılacak istem
 * @param maxTokens Maksimum token sayısı
 * @returns Oluşturulan metin
 */
export async function generateText(prompt: string, maxTokens = 1024): Promise<string> {
  try {
    // Text modeline erişim sağla
    const model = genAI.getGenerativeModel({
      model: TEXT_MODEL,
      safetySettings,
      generationConfig: {
        maxOutputTokens: maxTokens,
        temperature: 0.7,
        topP: 0.9,
      },
    });

    // İstemle metni oluştur ve yanıtı döndür
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    return text;
  } catch (error: any) {
    console.error("Metin oluştururken hata oluştu:", error);
    throw new Error(`Metin oluşturma hatası: ${error.message || error}`);
  }
}

/**
 * Metne dayalı görsel içerik oluşturur 
 * 
 * Not: Bu bir simülasyondur, Gemini henüz doğrudan resim oluşturma desteği sunmuyor.
 * Metni bir resim açıklaması olarak kullanıyoruz.
 * 
 * @param prompt Resim oluşturmak için kullanılacak istem
 * @returns Oluşturulan görsel içerik açıklaması
 */
export async function generateImageDescription(prompt: string): Promise<string> {
  try {
    // En iyi görsel anlatımlar için istem ekle
    const enhancedPrompt = `Bana bu görseli detaylı şekilde açıkla, adeta gerçekçi bir fotoğrafmış gibi: ${prompt}. 
    Şunları içersin: Görsel stil, renkler, kompozisyon, objeler, atmosfer ve duygu. 
    En fazla 200 kelime olsun.`;

    // Text modeline erişim sağla
    const model = genAI.getGenerativeModel({
      model: TEXT_MODEL,
      safetySettings,
      generationConfig: {
        maxOutputTokens: 512,
        temperature: 0.7,
        topP: 0.9,
      },
    });

    // İstemle metni oluştur ve yanıtı döndür
    const result = await model.generateContent(enhancedPrompt);
    const response = await result.response;
    const text = response.text();
    return text;
  } catch (error: any) {
    console.error("Görsel açıklaması oluştururken hata oluştu:", error);
    throw new Error(`Görsel açıklaması oluşturma hatası: ${error.message || error}`);
  }
}

/**
 * Sosyal medya için içerik oluşturur
 * @param prompt İçerik oluşturmak için kullanılacak istem
 * @param platform Hangi sosyal medya platformu için içerik oluşturulacağı
 * @returns Platform için uygun içerik metni
 */
export async function generateSocialMediaContent(
  prompt: string, 
  platform: string
): Promise<string> {
  try {
    // Platform özelliklerine göre uyarlanmış istem
    let platformSpecificPrompt = "";
    
    switch (platform.toLowerCase()) {
      case "instagram":
        platformSpecificPrompt = `Instagram için kısa, ilgi çekici ve hashtag'ler içeren bir gönderi yaz. 
        Gönderi hakkında: ${prompt}. 
        En fazla 150 kelime kullan ve 3-5 arası ilgili hashtag ekle.`;
        break;
      case "twitter":
        platformSpecificPrompt = `X (Twitter) için kısa, çarpıcı ve akılda kalıcı bir tweet yaz. 
        Tweet konusu: ${prompt}. 
        280 karakteri geçmeyecek şekilde ve varsa 1-2 hashtag kullan.`;
        break;
      case "facebook":
        platformSpecificPrompt = `Facebook için samimi, bilgilendirici ve etkileşim yaratacak bir gönderi yaz. 
        Gönderi konusu: ${prompt}.
        1-2 soru içersin ve okuyucuyu yorum yapmaya teşvik etsin.`;
        break;
      case "linkedin":
        platformSpecificPrompt = `LinkedIn için profesyonel, bilgilendirici ve değer katan bir gönderi yaz. 
        Gönderi konusu: ${prompt}.
        İş dünyasına hitap etsin, profesyonel tonda olsun ve varsa sektörel istatistikler içersin.`;
        break;
      case "youtube":
        platformSpecificPrompt = `YouTube için ilgi çekici bir video açıklaması yaz. 
        Video konusu: ${prompt}.
        Açıklama, izleyicileri videoyu izlemeye teşvik etmeli, içeriğin önemli noktalarını vurgulamalı 
        ve kullanıcıları abone olmaya ve yorum yapmaya yönlendirmeli.`;
        break;
      case "tiktok":
        platformSpecificPrompt = `TikTok için kısa, eğlenceli ve ilgi çekici bir açıklama yaz. 
        İçerik konusu: ${prompt}.
        Gençlere hitap eden bir dil kullan, güncel trendlere atıfta bulun ve 2-3 popüler hashtag ekle.`;
        break;
      default:
        platformSpecificPrompt = `Sosyal medya için ilgi çekici bir gönderi yaz. 
        Gönderi konusu: ${prompt}.`;
    }

    // Text modeline erişim sağla
    const model = genAI.getGenerativeModel({
      model: TEXT_MODEL,
      safetySettings,
      generationConfig: {
        maxOutputTokens: 512,
        temperature: 0.7,
        topP: 0.9,
      },
    });

    // İstemle metni oluştur ve yanıtı döndür
    const result = await model.generateContent(platformSpecificPrompt);
    const response = await result.response;
    const text = response.text();
    return text;
  } catch (error: any) {
    console.error("Sosyal medya içeriği oluştururken hata oluştu:", error);
    throw new Error(`Sosyal medya içeriği oluşturma hatası: ${error.message || error}`);
  }
}

/**
 * Platform için içerik ve görsel açıklaması oluşturur
 * @param prompt Genel içerik konusu
 * @param platform Hedef sosyal medya platformu
 * @returns İçerik metni ve görsel açıklaması
 */
export async function generateCompleteContent(
  prompt: string,
  platform: string
): Promise<{ text: string; imageDescription: string }> {
  // İçerik ve görsel açıklamasını paralel olarak oluştur
  const [content, imageDescription] = await Promise.all([
    generateSocialMediaContent(prompt, platform),
    generateImageDescription(`${prompt} için sosyal medyada paylaşılabilecek bir görsel`)
  ]);

  return {
    text: content,
    imageDescription
  };
}