import React, { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import Sidebar from "@/components/dashboard/sidebar";
import { DEMO_USER_ID, PLATFORM_DATA } from "@/lib/constants";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatDateRelative, getAvatarFallback, truncateText } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { Message } from "@shared/schema";
import useAccounts from "@/hooks/use-accounts";

export default function Messages() {
  const { toast } = useToast();
  const [selectedMessage, setSelectedMessage] = useState<Message | null>(null);
  const [replyContent, setReplyContent] = useState("");
  const [selectedTab, setSelectedTab] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  
  const { accounts, isLoading: isLoadingAccounts, activeAccount, setActiveAccount } = useAccounts();
  
  // Fetch messages for active account or first account
  const { data: messages, isLoading: isLoadingMessages } = useQuery({
    queryKey: [activeAccount ? `/api/messages/${activeAccount.id}` : null],
    enabled: !!activeAccount
  });
  
  // Calculate unread message counts
  const unreadMessageCounts: Record<string, number> = {};
  const totalUnreadCount = 0;
  
  // Mark message as read mutation
  const markAsReadMutation = useMutation({
    mutationFn: async (messageId: number) => {
      return apiRequest("PUT", `/api/messages/${messageId}/read`, null);
    },
    onSuccess: () => {
      // Invalidate messages query to refresh the data
      if (activeAccount) {
        queryClient.invalidateQueries({ queryKey: [`/api/messages/${activeAccount.id}`] });
      }
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Hata",
        description: "Mesaj okundu olarak işaretlenemedi."
      });
    }
  });
  
  // When a message is selected, mark it as read if it's unread
  useEffect(() => {
    if (selectedMessage && !selectedMessage.isRead) {
      markAsReadMutation.mutate(selectedMessage.id);
    }
  }, [selectedMessage]);
  
  // Filter messages based on active tab and search term
  const filteredMessages = messages?.filter(message => {
    const matchesPlatform = selectedTab === "all" || message.platform === selectedTab;
    const matchesSearch = !searchTerm || 
      message.senderName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      message.content.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesPlatform && matchesSearch;
  }) || [];
  
  // Handle sending a reply
  const handleSendReply = () => {
    if (!replyContent.trim() || !selectedMessage) return;
    
    // In a real app, this would send a reply to the message
    toast({
      title: "Yanıt gönderildi",
      description: `${selectedMessage.senderName} kullanıcısına yanıt gönderildi.`
    });
    
    setReplyContent("");
  };
  
  const isLoading = isLoadingAccounts || isLoadingMessages;
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col md:flex-row bg-gray-50">
        <Sidebar 
          accounts={accounts || []}
          unreadMessageCounts={unreadMessageCounts}
          activeAccount={activeAccount}
          onAccountChange={setActiveAccount}
        />
        <div className="flex-1 p-8 flex items-center justify-center">
          <div className="loading-pulse">
            <div className="text-center">
              <i className="ri-loader-4-line text-4xl text-primary mb-4"></i>
              <p className="text-gray-600">Mesajlar yükleniyor...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-gray-50">
      <Sidebar 
        accounts={accounts || []}
        unreadMessageCounts={unreadMessageCounts}
        activeAccount={activeAccount}
        onAccountChange={setActiveAccount}
      />
      
      <main className="flex-1 overflow-x-hidden">
        {/* Topbar */}
        <div className="bg-white border-b border-gray-200 px-4 py-4 flex items-center justify-between sticky top-0 z-10">
          <div>
            <h1 className="text-xl font-semibold text-gray-800">Mesajlar</h1>
            <p className="text-sm text-gray-500">Tüm platformlardan gelen mesajları yönetin</p>
          </div>
          
          {/* Quick actions */}
          <div className="flex items-center space-x-3">
            <Button variant="ghost" size="icon" className="p-2 text-gray-400 hover:text-gray-500 hover:bg-gray-100 rounded-full">
              <i className="ri-settings-3-line text-lg"></i>
            </Button>
            <Button className="hidden md:flex items-center space-x-2 px-4 py-2 border border-primary text-primary rounded-lg text-sm font-medium hover:bg-primary-50">
              <i className="ri-add-line"></i>
              <span>Yeni Mesaj</span>
            </Button>
          </div>
        </div>
        
        {/* Messages content */}
        <div className="h-[calc(100vh-73px)] flex">
          {/* Messages list */}
          <div className="w-full md:w-1/3 lg:w-1/4 border-r border-gray-200 bg-white">
            <div className="p-4 border-b border-gray-200">
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Mesajlarda ara..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8 pr-3 py-2 w-full text-sm border border-gray-300 rounded-lg"
                />
                <i className="ri-search-line absolute left-2.5 top-2.5 text-gray-400 text-sm"></i>
              </div>
            </div>
            
            <Tabs defaultValue="all" value={selectedTab} onValueChange={setSelectedTab}>
              <div className="px-4 pt-2">
                <TabsList className="w-full grid grid-cols-5">
                  <TabsTrigger value="all" className="text-xs">Tümü</TabsTrigger>
                  <TabsTrigger value="instagram" className="text-xs instagram-color">Instagram</TabsTrigger>
                  <TabsTrigger value="youtube" className="text-xs youtube-color">YouTube</TabsTrigger>
                  <TabsTrigger value="tiktok" className="text-xs tiktok-color">TikTok</TabsTrigger>
                  <TabsTrigger value="facebook" className="text-xs facebook-color">Facebook</TabsTrigger>
                </TabsList>
              </div>
              
              <TabsContent value="all" className="mt-0">
                {renderMessageList(filteredMessages)}
              </TabsContent>
              
              <TabsContent value="instagram" className="mt-0">
                {renderMessageList(filteredMessages.filter(m => m.platform === "instagram"))}
              </TabsContent>
              
              <TabsContent value="youtube" className="mt-0">
                {renderMessageList(filteredMessages.filter(m => m.platform === "youtube"))}
              </TabsContent>
              
              <TabsContent value="tiktok" className="mt-0">
                {renderMessageList(filteredMessages.filter(m => m.platform === "tiktok"))}
              </TabsContent>
              
              <TabsContent value="facebook" className="mt-0">
                {renderMessageList(filteredMessages.filter(m => m.platform === "facebook"))}
              </TabsContent>
            </Tabs>
          </div>
          
          {/* Message detail */}
          <div className="hidden md:flex md:flex-col md:w-2/3 lg:w-3/4">
            {selectedMessage ? (
              <>
                {/* Message header */}
                <div className="p-4 border-b border-gray-200 flex items-center justify-between bg-white">
                  <div className="flex items-center">
                    <Avatar className="mr-3">
                      <AvatarImage src={selectedMessage.senderAvatar || ""} alt={selectedMessage.senderName} />
                      <AvatarFallback>{getAvatarFallback(selectedMessage.senderName)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-medium text-gray-900">{selectedMessage.senderName}</h3>
                      <div className="flex items-center text-xs text-gray-500">
                        <span className={`w-2 h-2 rounded-full mr-1 ${
                          selectedMessage.platform === "instagram" ? "bg-[#E1306C]" :
                          selectedMessage.platform === "youtube" ? "bg-[#FF0000]" :
                          selectedMessage.platform === "tiktok" ? "bg-black" : "bg-[#4267B2]"
                        }`}></span>
                        <span>{PLATFORM_DATA[selectedMessage.platform]?.label}</span>
                        <span className="mx-1">•</span>
                        <span>{formatDateRelative(selectedMessage.timestamp)}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="icon">
                      <i className="ri-user-line text-gray-500"></i>
                    </Button>
                    <Button variant="ghost" size="icon">
                      <i className="ri-more-2-fill text-gray-500"></i>
                    </Button>
                  </div>
                </div>
                
                {/* Message content */}
                <div className="flex-1 p-6 overflow-y-auto bg-gray-50">
                  <div className="mb-6">
                    <div className="bg-white rounded-lg p-4 shadow-sm max-w-xl">
                      <p className="text-gray-800">{selectedMessage.content}</p>
                    </div>
                    <div className="text-xs text-gray-500 ml-2 mt-1">
                      {new Date(selectedMessage.timestamp).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                  
                  {/* Reply area - would contain actual replies in a real app */}
                </div>
                
                {/* Reply input */}
                <div className="p-4 border-t border-gray-200 bg-white">
                  <div className="flex items-center">
                    <Input
                      type="text"
                      placeholder="Yanıtınızı yazın..."
                      value={replyContent}
                      onChange={(e) => setReplyContent(e.target.value)}
                      className="flex-1 border border-gray-300 rounded-l-lg py-2"
                    />
                    <Button 
                      onClick={handleSendReply}
                      disabled={!replyContent.trim()}
                      className="rounded-l-none"
                    >
                      <i className="ri-send-plane-fill mr-1"></i>
                      Gönder
                    </Button>
                  </div>
                </div>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-center p-6 bg-gray-50">
                <div className="w-16 h-16 rounded-full bg-primary-100 flex items-center justify-center mb-4">
                  <i className="ri-message-3-line text-primary text-2xl"></i>
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-1">Mesaj seçilmedi</h3>
                <p className="text-gray-500 max-w-md">
                  Bir mesaj görüntülemek için listeden bir mesaj seçin veya yeni bir mesaj oluşturun.
                </p>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
  
  function renderMessageList(messageList: Message[]) {
    if (messageList.length === 0) {
      return (
        <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
          <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center mb-3">
            <i className="ri-inbox-line text-gray-400 text-xl"></i>
          </div>
          <p className="text-gray-500">Bu sekmede hiç mesaj yok</p>
        </div>
      );
    }
    
    return (
      <div className="overflow-y-auto h-[calc(100vh-170px)]">
        {messageList.map(message => (
          <div 
            key={message.id} 
            className={`flex items-center p-4 cursor-pointer transition-colors ${
              selectedMessage?.id === message.id 
                ? "bg-primary-50 border-l-2 border-primary" 
                : "hover:bg-gray-50 border-l-2 border-transparent"
            }`}
            onClick={() => setSelectedMessage(message)}
          >
            <div className="relative">
              <Avatar>
                <AvatarImage src={message.senderAvatar || ""} alt={message.senderName} />
                <AvatarFallback>{getAvatarFallback(message.senderName)}</AvatarFallback>
              </Avatar>
              <div className={`absolute -bottom-1 -right-1 w-3 h-3 ${message.isRead ? 'bg-gray-300' : 'bg-primary'} border-2 border-white rounded-full`}></div>
              
              {/* Platform icon badge */}
              <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-white border border-gray-200 flex items-center justify-center text-xs shadow-sm">
                {message.platform === "instagram" && (
                  <i className="ri-instagram-line text-[#E1306C]" />
                )}
                {message.platform === "youtube" && (
                  <i className="ri-youtube-line text-[#FF0000]" />
                )}
                {message.platform === "tiktok" && (
                  <i className="ri-tiktok-line text-black" />
                )}
                {message.platform === "facebook" && (
                  <i className="ri-facebook-fill text-[#4267B2]" />
                )}
                {message.platform === "twitter" && (
                  <i className="ri-twitter-x-line text-black" />
                )}
              </div>
            </div>
            <div className="ml-3 flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-gray-900 truncate">{message.senderName}</p>
                <span className="text-xs text-gray-500">
                  {formatDateRelative(message.timestamp)}
                </span>
              </div>
              <div className="flex items-center mt-1">
                <span className={`w-2 h-2 rounded-full mr-1 ${
                  message.platform === "instagram" ? "bg-[#E1306C]" :
                  message.platform === "youtube" ? "bg-[#FF0000]" :
                  message.platform === "tiktok" ? "bg-black" : "bg-[#4267B2]"
                }`}></span>
                <p className="text-xs text-gray-500 truncate">{truncateText(message.content, 40)}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }
}
