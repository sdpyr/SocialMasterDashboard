import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  AlertCircle, 
  PenSquare, 
  Save, 
  User, 
  Plus, 
  Instagram, 
  Youtube, 
  Facebook, 
  Twitter, 
  Linkedin, 
  PlusCircle,
  Trash2 
} from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { PlatformEnum, type SocialAccount } from "@shared/schema";
import { getAvatarFallback } from "@/lib/utils";

export default function UserSettings() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saveLoading, setSaveLoading] = useState(false);
  const [user, setUser] = useState(null);
  const [userProfile, setUserProfile] = useState({
    fullName: "",
    email: "",
    avatarUrl: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [notifications, setNotifications] = useState({
    emailNotifications: true,
    messageNotifications: true,
    activityNotifications: true,
    weeklyReports: true,
  });
  
  // Sosyal medya hesapları
  const [socialAccounts, setSocialAccounts] = useState<SocialAccount[]>([]);
  const [openAddAccountDialog, setOpenAddAccountDialog] = useState(false);
  const [socialAccountFormData, setSocialAccountFormData] = useState({
    name: "",
    username: "",
    platform: PlatformEnum.enum.instagram,
    accountId: "",
    avatarUrl: "",
  });
  
  // Kullanıcı bilgilerini getir
  useEffect(() => {
    const fetchUserData = async () => {
      setLoading(true);
      try {
        const response = await apiRequest("GET", "/api/user");
        const userData = await response.json();
        setUser(userData);
        setUserProfile({
          fullName: userData.fullName || "",
          email: userData.email || "",
          avatarUrl: userData.avatarUrl || "",
          newPassword: "",
          confirmPassword: "",
        });
        // Normalde burada bildirim ayarlarını API'den alırdık
        // Örnek veri kullanıyoruz
        setNotifications({
          emailNotifications: true,
          messageNotifications: true,
          activityNotifications: true,
          weeklyReports: true,
        });
        
        // Sosyal medya hesaplarını getir
        if (userData.id) {
          try {
            const accountsResponse = await apiRequest("GET", `/api/accounts/${userData.id}`);
            const accounts = await accountsResponse.json();
            setSocialAccounts(accounts);
          } catch (error) {
            console.error("Sosyal medya hesapları getirilirken hata:", error);
          }
        }
      } catch (error) {
        console.error("Kullanıcı bilgileri getirilirken hata:", error);
        toast({
          title: "Hata",
          description: "Kullanıcı bilgileri yüklenemedi.",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, [toast]);

  // Form değişikliklerini yönet
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUserProfile((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // Bildirim ayarlarını değiştir
  const handleNotificationChange = (key, value) => {
    setNotifications((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  // Profil güncelleme
  const handleProfileUpdate = async () => {
    setSaveLoading(true);
    try {
      // Parola alanları dolu ise eşleşip eşleşmediklerini kontrol et
      if (userProfile.newPassword && userProfile.newPassword !== userProfile.confirmPassword) {
        toast({
          title: "Hata",
          description: "Parolalar eşleşmiyor.",
          variant: "destructive",
        });
        setSaveLoading(false);
        return;
      }

      // API'ye gönderilecek veri
      const updateData = {
        fullName: userProfile.fullName,
        email: userProfile.email,
        avatarUrl: userProfile.avatarUrl,
      };

      // Eğer yeni parola belirtildiyse ekle
      if (userProfile.newPassword) {
        updateData.password = userProfile.newPassword;
      }

      // Kullanıcı bilgilerini güncelle
      const response = await apiRequest(
        "PATCH",
        `/api/user/${user.id}`,
        updateData
      );

      if (response.ok) {
        toast({
          title: "Başarılı",
          description: "Kullanıcı bilgileriniz güncellendi.",
        });
        
        // Bildirim ayarlarını güncelle
        await apiRequest(
          "POST",
          "/api/user-notifications",
          notifications
        );
        
        // Kullanıcı bilgilerini yeniden getir
        queryClient.invalidateQueries(["/api/user"]);
      } else {
        toast({
          title: "Hata",
          description: "Kullanıcı bilgileri güncellenirken bir hata oluştu.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Profil güncellenirken hata:", error);
      toast({
        title: "Hata",
        description: "Profil güncellenirken bir hata oluştu.",
        variant: "destructive",
      });
    } finally {
      setSaveLoading(false);
    }
  };

  // Abonelik planına yükselt butonunu göster
  const renderUpgradeButton = () => {
    if (!user) return null;
    
    // Kullanıcı zaten Ultimate aboneliğe sahipse gösterme
    if (user.subscriptionTier === "ultimate") return null;
    
    return (
      <Button 
        variant="outline" 
        className="ml-auto" 
        onClick={() => {
          // Ödeme sayfasına yönlendir
          window.location.href = "/odeme";
        }}
      >
        Abonelik Planını Yükselt
      </Button>
    );
  };

  if (loading) {
    return (
      <div className="container mx-auto py-8 flex items-center justify-center min-h-[500px]">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Hesap Ayarları</h1>
        {renderUpgradeButton()}
      </div>

      <Tabs defaultValue="profile">
        <TabsList className="mb-6">
          <TabsTrigger value="profile">Profil</TabsTrigger>
          <TabsTrigger value="social-accounts">Sosyal Medya Hesapları</TabsTrigger>
          <TabsTrigger value="notifications">Bildirimler</TabsTrigger>
          <TabsTrigger value="subscription">Abonelik</TabsTrigger>
        </TabsList>

        <TabsContent value="profile">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle>Profil Bilgileri</CardTitle>
                  <CardDescription>
                    Kişisel bilgilerinizi ve profil fotoğrafınızı güncelleyin.
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col items-center space-y-4">
                  <Avatar className="w-32 h-32">
                    <AvatarImage src={userProfile.avatarUrl} />
                    <AvatarFallback className="text-2xl">
                      {user && getAvatarFallback(user.fullName)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="text-center">
                    <h3 className="font-medium">{user?.username}</h3>
                    <p className="text-sm text-gray-500">{user?.email}</p>
                  </div>
                  <Button variant="outline" size="sm">
                    <PenSquare className="h-4 w-4 mr-2" />
                    Fotoğraf Değiştir
                  </Button>
                </CardContent>
              </Card>
            </div>

            <div className="md:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Bilgilerinizi Düzenleyin</CardTitle>
                  <CardDescription>
                    Kişisel bilgilerinizi ve şifrenizi güncelleyin.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="fullName">Tam Ad</Label>
                    <Input
                      id="fullName"
                      name="fullName"
                      value={userProfile.fullName}
                      onChange={handleInputChange}
                      placeholder="Tam adınız"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">E-posta</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={userProfile.email}
                      onChange={handleInputChange}
                      placeholder="E-posta adresiniz"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="newPassword">Yeni Şifre</Label>
                    <Input
                      id="newPassword"
                      name="newPassword"
                      type="password"
                      value={userProfile.newPassword}
                      onChange={handleInputChange}
                      placeholder="Yeni şifreniz"
                    />
                    <p className="text-xs text-gray-500">
                      Boş bırakırsanız şifreniz değişmeyecektir.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Şifre Tekrar</Label>
                    <Input
                      id="confirmPassword"
                      name="confirmPassword"
                      type="password"
                      value={userProfile.confirmPassword}
                      onChange={handleInputChange}
                      placeholder="Yeni şifrenizi tekrar girin"
                    />
                  </div>
                  <Button
                    className="w-full mt-4"
                    onClick={handleProfileUpdate}
                    disabled={saveLoading}
                  >
                    {saveLoading ? (
                      <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                    ) : (
                      <Save className="h-4 w-4 mr-2" />
                    )}
                    Değişiklikleri Kaydet
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="social-accounts">
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Sosyal Medya Hesaplarınız</h2>
              <Button 
                variant="outline" 
                onClick={() => setOpenAddAccountDialog(true)}
              >
                <Plus className="h-4 w-4 mr-2" />
                Yeni Hesap Ekle
              </Button>
            </div>
            
            {socialAccounts.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <div className="bg-gray-100 rounded-full p-4 mb-4">
                    <User className="h-10 w-10 text-gray-500" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">Henüz Sosyal Medya Hesabı Eklenmemiş</h3>
                  <p className="text-sm text-gray-500 text-center mb-4">
                    İçerik oluşturmak ve yönetmek için hesap ekleyin
                  </p>
                  <Button 
                    variant="secondary" 
                    onClick={() => setOpenAddAccountDialog(true)}
                  >
                    <PlusCircle className="h-4 w-4 mr-2" />
                    Hesap Ekle
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {socialAccounts.map((account) => (
                  <Card key={account.id}>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center">
                          <Avatar className="h-10 w-10 mr-3">
                            <AvatarImage src={account.avatarUrl || undefined} />
                            <AvatarFallback className={`${
                              account.platform === "instagram" ? "bg-pink-100 text-pink-600" :
                              account.platform === "youtube" ? "bg-red-100 text-red-600" :
                              account.platform === "tiktok" ? "bg-gray-100 text-gray-600" :
                              account.platform === "facebook" ? "bg-blue-100 text-blue-600" :
                              account.platform === "twitter" ? "bg-sky-100 text-sky-600" :
                              "bg-blue-100 text-blue-600"
                            }`}>
                              {account.platform === "instagram" ? <Instagram className="h-5 w-5" /> :
                              account.platform === "youtube" ? <Youtube className="h-5 w-5" /> :
                              account.platform === "facebook" ? <Facebook className="h-5 w-5" /> :
                              account.platform === "twitter" ? <Twitter className="h-5 w-5" /> :
                              account.platform === "linkedin" ? <Linkedin className="h-5 w-5" /> :
                              account.name.slice(0, 2)
                              }
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <h3 className="font-medium">{account.name}</h3>
                            <p className="text-xs text-gray-500">@{account.username}</p>
                          </div>
                        </div>
                        <div className={`px-2 py-1 rounded-full text-xs ${
                          account.isActive 
                          ? "bg-green-100 text-green-600" 
                          : "bg-gray-100 text-gray-600"
                        }`}>
                          {account.isActive ? "Aktif" : "Pasif"}
                        </div>
                      </div>
                      
                      <div className="flex justify-between mt-4">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          className="text-gray-500 hover:text-gray-800"
                          onClick={() => {
                            // Edit account
                          }}
                        >
                          <PenSquare className="h-4 w-4 mr-1" />
                          Düzenle
                        </Button>
                        
                        <Button 
                          variant="ghost" 
                          size="sm"
                          className="text-red-500 hover:text-red-700"
                          onClick={() => {
                            // Delete account
                          }}
                        >
                          <Trash2 className="h-4 w-4 mr-1" />
                          Sil
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>

          {/* Add Account Dialog */}
          <Dialog open={openAddAccountDialog} onOpenChange={setOpenAddAccountDialog}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Sosyal Medya Hesabı Ekle</DialogTitle>
                <DialogDescription>
                  Yönetmek istediğiniz sosyal medya hesabınızın bilgilerini girin.
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="platform">Platform</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <Button
                      type="button"
                      variant={socialAccountFormData.platform === "instagram" ? "default" : "outline"}
                      className={`flex items-center justify-center py-6 ${
                        socialAccountFormData.platform === "instagram" ? "border-primary" : ""
                      }`}
                      onClick={() => setSocialAccountFormData(prev => ({ ...prev, platform: "instagram" }))}
                    >
                      <Instagram className="h-6 w-6" />
                    </Button>
                    <Button
                      type="button"
                      variant={socialAccountFormData.platform === "youtube" ? "default" : "outline"}
                      className={`flex items-center justify-center py-6 ${
                        socialAccountFormData.platform === "youtube" ? "border-primary" : ""
                      }`}
                      onClick={() => setSocialAccountFormData(prev => ({ ...prev, platform: "youtube" }))}
                    >
                      <Youtube className="h-6 w-6" />
                    </Button>
                    <Button
                      type="button"
                      variant={socialAccountFormData.platform === "facebook" ? "default" : "outline"}
                      className={`flex items-center justify-center py-6 ${
                        socialAccountFormData.platform === "facebook" ? "border-primary" : ""
                      }`}
                      onClick={() => setSocialAccountFormData(prev => ({ ...prev, platform: "facebook" }))}
                    >
                      <Facebook className="h-6 w-6" />
                    </Button>
                    <Button
                      type="button"
                      variant={socialAccountFormData.platform === "twitter" ? "default" : "outline"}
                      className={`flex items-center justify-center py-6 ${
                        socialAccountFormData.platform === "twitter" ? "border-primary" : ""
                      }`}
                      onClick={() => setSocialAccountFormData(prev => ({ ...prev, platform: "twitter" }))}
                    >
                      <Twitter className="h-6 w-6" />
                    </Button>
                    <Button
                      type="button"
                      variant={socialAccountFormData.platform === "linkedin" ? "default" : "outline"}
                      className={`flex items-center justify-center py-6 ${
                        socialAccountFormData.platform === "linkedin" ? "border-primary" : ""
                      }`}
                      onClick={() => setSocialAccountFormData(prev => ({ ...prev, platform: "linkedin" }))}
                    >
                      <Linkedin className="h-6 w-6" />
                    </Button>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="name">Hesap Adı</Label>
                  <Input
                    id="name"
                    value={socialAccountFormData.name}
                    onChange={(e) => setSocialAccountFormData(prev => ({ 
                      ...prev, 
                      name: e.target.value 
                    }))}
                    placeholder="Hesap adı veya marka adı"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="username">Kullanıcı Adı</Label>
                  <Input
                    id="username"
                    value={socialAccountFormData.username}
                    onChange={(e) => setSocialAccountFormData(prev => ({ 
                      ...prev, 
                      username: e.target.value 
                    }))}
                    placeholder="Kullanıcı adı"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="accountId">Hesap ID</Label>
                  <Input
                    id="accountId"
                    value={socialAccountFormData.accountId}
                    onChange={(e) => setSocialAccountFormData(prev => ({ 
                      ...prev, 
                      accountId: e.target.value 
                    }))}
                    placeholder="Hesap ID"
                  />
                  <p className="text-xs text-gray-500">
                    Platformunuzdaki hesap ID numaranız veya kullanıcı adınız.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="avatarUrl">Profil Fotoğrafı URL (İsteğe Bağlı)</Label>
                  <Input
                    id="avatarUrl"
                    value={socialAccountFormData.avatarUrl}
                    onChange={(e) => setSocialAccountFormData(prev => ({ 
                      ...prev, 
                      avatarUrl: e.target.value 
                    }))}
                    placeholder="https://..."
                  />
                </div>

                <div className="border-t pt-4 mt-4">
                  <h3 className="font-medium mb-2">API Bağlantı Bilgileri</h3>
                  <p className="text-sm text-gray-500 mb-4">
                    İçerik paylaşabilmek için lütfen hesabınızın API bilgilerini ekleyin. Bu bilgiler şifrelenmiş şekilde saklanacak ve sadece içerik paylaşımı için kullanılacaktır.
                  </p>

                  {socialAccountFormData.platform === "instagram" && (
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="apiKey">Instagram Access Token</Label>
                        <Input
                          id="apiKey"
                          type="password"
                          value={socialAccountFormData.apiKey || ""}
                          onChange={(e) => setSocialAccountFormData(prev => ({ 
                            ...prev, 
                            apiKey: e.target.value 
                          }))}
                          placeholder="IGQVJXxxxxxxx..."
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="apiSecret">Client Secret</Label>
                        <Input
                          id="apiSecret"
                          type="password"
                          value={socialAccountFormData.apiSecret || ""}
                          onChange={(e) => setSocialAccountFormData(prev => ({ 
                            ...prev, 
                            apiSecret: e.target.value 
                          }))}
                          placeholder="Meta Developer hesabınızdaki client secret"
                        />
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-amber-600 flex items-center">
                          <AlertCircle className="h-3 w-3 mr-1" />
                          Instagram API token almak için Meta Developer platformunda uygulama oluşturmanız gerekmektedir.
                        </p>
                        <p className="text-xs text-blue-500 ml-4">
                          <a href="https://developers.facebook.com/docs/instagram-basic-display-api/getting-started" target="_blank" rel="noopener noreferrer">
                            Nasıl token alınır? Dokümantasyonu görüntüle →
                          </a>
                        </p>
                      </div>
                    </div>
                  )}

                  {socialAccountFormData.platform === "youtube" && (
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="apiKey">YouTube API Key</Label>
                        <Input
                          id="apiKey"
                          type="password"
                          value={socialAccountFormData.apiKey || ""}
                          onChange={(e) => setSocialAccountFormData(prev => ({ 
                            ...prev, 
                            apiKey: e.target.value 
                          }))}
                          placeholder="AIzaSyxxxxxxxxxxxxxxxx"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="refreshToken">OAuth Refresh Token</Label>
                        <Input
                          id="refreshToken"
                          type="password"
                          value={socialAccountFormData.refreshToken || ""}
                          onChange={(e) => setSocialAccountFormData(prev => ({ 
                            ...prev, 
                            refreshToken: e.target.value 
                          }))}
                          placeholder="1//xxxxxxxxxxxxxx"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="clientId">Client ID</Label>
                        <Input
                          id="clientId"
                          type="password"
                          value={socialAccountFormData.clientId || ""}
                          onChange={(e) => setSocialAccountFormData(prev => ({ 
                            ...prev, 
                            clientId: e.target.value 
                          }))}
                          placeholder="123456789-xxxxxxxxxxx.apps.googleusercontent.com"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="apiSecret">Client Secret</Label>
                        <Input
                          id="apiSecret"
                          type="password"
                          value={socialAccountFormData.apiSecret || ""}
                          onChange={(e) => setSocialAccountFormData(prev => ({ 
                            ...prev, 
                            apiSecret: e.target.value 
                          }))}
                          placeholder="GOCSPX-xxxxxxxx"
                        />
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-amber-600 flex items-center">
                          <AlertCircle className="h-3 w-3 mr-1" />
                          YouTube API kullanımı için Google Cloud Console'dan bir proje oluşturmanız gerekmektedir.
                        </p>
                        <p className="text-xs text-blue-500 ml-4">
                          <a href="https://developers.google.com/youtube/v3/getting-started" target="_blank" rel="noopener noreferrer">
                            Nasıl API key alınır? Dokümantasyonu görüntüle →
                          </a>
                        </p>
                      </div>
                    </div>
                  )}

                  {socialAccountFormData.platform === "facebook" && (
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="accessToken">Facebook Page Access Token</Label>
                        <Input
                          id="accessToken"
                          type="password"
                          value={socialAccountFormData.accessToken || ""}
                          onChange={(e) => setSocialAccountFormData(prev => ({ 
                            ...prev, 
                            accessToken: e.target.value 
                          }))}
                          placeholder="EAAxxxxxxx..."
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="pageId">Facebook Sayfa ID</Label>
                        <Input
                          id="pageId"
                          value={socialAccountFormData.pageId || ""}
                          onChange={(e) => setSocialAccountFormData(prev => ({ 
                            ...prev, 
                            pageId: e.target.value 
                          }))}
                          placeholder="123456789012345"
                        />
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-amber-600 flex items-center">
                          <AlertCircle className="h-3 w-3 mr-1" />
                          Facebook API kullanımı için Meta for Developers platformundan bir uygulama oluşturmanız gerekmektedir.
                        </p>
                        <p className="text-xs text-blue-500 ml-4">
                          <a href="https://developers.facebook.com/docs/pages/access-tokens" target="_blank" rel="noopener noreferrer">
                            Nasıl token alınır? Dokümantasyonu görüntüle →
                          </a>
                        </p>
                      </div>
                    </div>
                  )}

                  {socialAccountFormData.platform === "twitter" && (
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="apiKey">API Key</Label>
                        <Input
                          id="apiKey"
                          type="password"
                          value={socialAccountFormData.apiKey || ""}
                          onChange={(e) => setSocialAccountFormData(prev => ({ 
                            ...prev, 
                            apiKey: e.target.value 
                          }))}
                          placeholder="xxxxxxxx"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="apiSecret">API Key Secret</Label>
                        <Input
                          id="apiSecret"
                          type="password"
                          value={socialAccountFormData.apiSecret || ""}
                          onChange={(e) => setSocialAccountFormData(prev => ({ 
                            ...prev, 
                            apiSecret: e.target.value 
                          }))}
                          placeholder="xxxxxxxx"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="accessToken">Access Token</Label>
                        <Input
                          id="accessToken"
                          type="password"
                          value={socialAccountFormData.accessToken || ""}
                          onChange={(e) => setSocialAccountFormData(prev => ({ 
                            ...prev, 
                            accessToken: e.target.value 
                          }))}
                          placeholder="xxxxxxxx"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="accessTokenSecret">Access Token Secret</Label>
                        <Input
                          id="accessTokenSecret"
                          type="password"
                          value={socialAccountFormData.accessTokenSecret || ""}
                          onChange={(e) => setSocialAccountFormData(prev => ({ 
                            ...prev, 
                            accessTokenSecret: e.target.value 
                          }))}
                          placeholder="xxxxxxxx"
                        />
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-amber-600 flex items-center">
                          <AlertCircle className="h-3 w-3 mr-1" />
                          Twitter API kullanmak için Twitter Developer hesabı ve bir uygulama oluşturmanız gerekmektedir.
                        </p>
                        <p className="text-xs text-blue-500 ml-4">
                          <a href="https://developer.twitter.com/en/docs/twitter-api/getting-started/getting-access-to-the-twitter-api" target="_blank" rel="noopener noreferrer">
                            Nasıl API erişimi alınır? Dokümantasyonu görüntüle →
                          </a>
                        </p>
                      </div>
                    </div>
                  )}
                  
                  {socialAccountFormData.platform === "linkedin" && (
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="accessToken">LinkedIn Access Token</Label>
                        <Input
                          id="accessToken"
                          type="password"
                          value={socialAccountFormData.accessToken || ""}
                          onChange={(e) => setSocialAccountFormData(prev => ({ 
                            ...prev, 
                            accessToken: e.target.value 
                          }))}
                          placeholder="AQxxxxxxxx"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="clientId">Client ID</Label>
                        <Input
                          id="clientId"
                          type="password"
                          value={socialAccountFormData.clientId || ""}
                          onChange={(e) => setSocialAccountFormData(prev => ({ 
                            ...prev, 
                            clientId: e.target.value 
                          }))}
                          placeholder="xxxxxxxx"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="apiSecret">Client Secret</Label>
                        <Input
                          id="apiSecret"
                          type="password"
                          value={socialAccountFormData.apiSecret || ""}
                          onChange={(e) => setSocialAccountFormData(prev => ({ 
                            ...prev, 
                            apiSecret: e.target.value 
                          }))}
                          placeholder="xxxxxxxx"
                        />
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-amber-600 flex items-center">
                          <AlertCircle className="h-3 w-3 mr-1" />
                          LinkedIn API kullanmak için LinkedIn Developer platformunda bir uygulama oluşturmanız gerekmektedir.
                        </p>
                        <p className="text-xs text-blue-500 ml-4">
                          <a href="https://www.linkedin.com/developers/apps/new" target="_blank" rel="noopener noreferrer">
                            Nasıl API erişimi alınır? Dokümantasyonu görüntüle →
                          </a>
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
              
              <DialogFooter>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setSocialAccountFormData({
                      name: "",
                      username: "",
                      platform: PlatformEnum.enum.instagram,
                      accountId: "",
                      avatarUrl: "",
                    });
                    setOpenAddAccountDialog(false);
                  }}
                >
                  İptal
                </Button>
                <Button 
                  onClick={async () => {
                    if (!user) return;
                    
                    if (!socialAccountFormData.name || !socialAccountFormData.username || !socialAccountFormData.accountId) {
                      toast({
                        title: "Eksik Bilgiler",
                        description: "Lütfen gerekli alanları doldurun.",
                        variant: "destructive",
                      });
                      return;
                    }
                    
                    try {
                      const response = await apiRequest(
                        "POST", 
                        "/api/social-accounts", 
                        {
                          ...socialAccountFormData,
                          userId: user.id,
                          isActive: true,
                        }
                      );
                      
                      if (response.ok) {
                        toast({
                          title: "Başarılı",
                          description: "Sosyal medya hesabı başarıyla eklendi.",
                        });
                        
                        // Hesabı ekleme sonrası form alanını temizle
                        setSocialAccountFormData({
                          name: "",
                          username: "",
                          platform: PlatformEnum.enum.instagram,
                          accountId: "",
                          avatarUrl: "",
                        });
                        
                        // Dialog'u kapat
                        setOpenAddAccountDialog(false);
                        
                        // Hesap listesini yeniden yükle
                        if (user.id) {
                          const accountsResponse = await apiRequest("GET", `/api/accounts/${user.id}`);
                          const accounts = await accountsResponse.json();
                          setSocialAccounts(accounts);
                        }
                      } else {
                        const errorData = await response.json();
                        toast({
                          title: "Hata",
                          description: errorData.message || "Hesap eklenirken bir hata oluştu.",
                          variant: "destructive",
                        });
                      }
                    } catch (error) {
                      console.error("Sosyal medya hesabı eklenirken hata:", error);
                      toast({
                        title: "Hata",
                        description: "Sosyal medya hesabı eklenirken bir hata oluştu.",
                        variant: "destructive",
                      });
                    }
                  }}
                >
                  Hesap Ekle
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </TabsContent>

        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Bildirim Tercihleri</CardTitle>
              <CardDescription>
                Hangi konularda bildirim almak istediğinizi yapılandırın.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">E-posta Bildirimleri</h3>
                  <p className="text-sm text-gray-500">
                    Önemli güncellemeler ve etkinlikler hakkında e-posta bildirimleri alın.
                  </p>
                </div>
                <Switch
                  checked={notifications.emailNotifications}
                  onCheckedChange={(checked) =>
                    handleNotificationChange("emailNotifications", checked)
                  }
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Mesaj Bildirimleri</h3>
                  <p className="text-sm text-gray-500">
                    Sosyal medya hesaplarınıza gelen mesajlar için bildirimler alın.
                  </p>
                </div>
                <Switch
                  checked={notifications.messageNotifications}
                  onCheckedChange={(checked) =>
                    handleNotificationChange("messageNotifications", checked)
                  }
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Aktivite Bildirimleri</h3>
                  <p className="text-sm text-gray-500">
                    Hesaplarınızdaki beğeni, yorum ve takipçi etkinlikleri için bildirimler alın.
                  </p>
                </div>
                <Switch
                  checked={notifications.activityNotifications}
                  onCheckedChange={(checked) =>
                    handleNotificationChange("activityNotifications", checked)
                  }
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Haftalık Raporlar</h3>
                  <p className="text-sm text-gray-500">
                    Sosyal medya performansınız hakkında haftalık özet raporlar alın.
                  </p>
                </div>
                <Switch
                  checked={notifications.weeklyReports}
                  onCheckedChange={(checked) =>
                    handleNotificationChange("weeklyReports", checked)
                  }
                />
              </div>
              
              <Button
                className="mt-4"
                onClick={handleProfileUpdate}
                disabled={saveLoading}
              >
                {saveLoading ? (
                  <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                ) : (
                  <Save className="h-4 w-4 mr-2" />
                )}
                Bildirimleri Kaydet
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="subscription">
          <Card>
            <CardHeader>
              <CardTitle>Abonelik Bilgileri</CardTitle>
              <CardDescription>
                Mevcut abonelik planınız ve kullanım sınırlarınız.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">Mevcut Plan</h3>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex items-center">
                      <span
                        className={`px-2 py-1 rounded-full text-xs font-medium mr-2 ${
                          user?.subscriptionTier === "free"
                            ? "bg-gray-100"
                            : user?.subscriptionTier === "premium"
                            ? "bg-blue-100 text-blue-800"
                            : "bg-purple-100 text-purple-800"
                        }`}
                      >
                        {user?.subscriptionTier === "free"
                          ? "Ücretsiz"
                          : user?.subscriptionTier === "premium"
                          ? "Premium"
                          : "Ultimate"}
                      </span>
                      <span className="text-sm text-gray-500">
                        {user?.subscriptionTier === "free"
                          ? "Sınırlı erişim"
                          : user?.subscriptionTier === "premium"
                          ? "Gelişmiş özellikler"
                          : "Sınırsız erişim"}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="text-lg font-medium">Kullanım Sınırları</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-medium mb-2">Platform Sayısı</h4>
                      <div className="flex justify-between items-center">
                        <span className="text-2xl font-bold">
                          {user?.subscriptionTier === "free"
                            ? "1"
                            : user?.subscriptionTier === "premium"
                            ? "4"
                            : "Sınırsız"}
                        </span>
                        <span className="text-sm text-gray-500">
                          {user?.subscriptionTier === "free"
                            ? "Maksimum"
                            : user?.subscriptionTier === "premium"
                            ? "Maksimum"
                            : ""}
                        </span>
                      </div>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-medium mb-2">Haftalık Gönderi</h4>
                      <div className="flex justify-between items-center">
                        <span className="text-2xl font-bold">
                          {user?.subscriptionTier === "free"
                            ? "1"
                            : user?.subscriptionTier === "premium"
                            ? "10"
                            : "Sınırsız"}
                        </span>
                        <span className="text-sm text-gray-500">
                          {user?.subscriptionTier === "free"
                            ? "Maksimum"
                            : user?.subscriptionTier === "premium"
                            ? "Maksimum"
                            : ""}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="text-lg font-medium">Yapay Zeka Özellikleri</h3>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <ul className="space-y-2">
                      <li className="flex items-center text-sm">
                        <div className={`w-2 h-2 rounded-full mr-2 ${
                          user?.subscriptionTier !== "free" ? "bg-green-500" : "bg-red-500"
                        }`}></div>
                        <span>İçerik Oluşturma</span>
                      </li>
                      <li className="flex items-center text-sm">
                        <div className={`w-2 h-2 rounded-full mr-2 ${
                          user?.subscriptionTier !== "free" ? "bg-green-500" : "bg-red-500"
                        }`}></div>
                        <span>Görsel Açıklamaları</span>
                      </li>
                      <li className="flex items-center text-sm">
                        <div className={`w-2 h-2 rounded-full mr-2 ${
                          user?.subscriptionTier === "ultimate" ? "bg-green-500" : "bg-red-500"
                        }`}></div>
                        <span>Gelişmiş Analitikler</span>
                      </li>
                    </ul>
                  </div>
                </div>

                <div className="pt-4">
                  {user?.subscriptionTier !== "ultimate" && (
                    <Button onClick={() => window.location.href = "/odeme"}>
                      Abonelik Planını Yükselt
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}