import React, { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Sidebar from "@/components/dashboard/sidebar";
import { StatsCard, StatsCardWithPlatformBar, StatsCardWithProgress, StatsCardWithBarChart } from "@/components/dashboard/stats-card";
import { ChartGrowth } from "@/components/dashboard/chart-growth";
import { ChartEngagement } from "@/components/dashboard/chart-engagement";
import { ActivityFeed } from "@/components/dashboard/activity-feed";
import { MessageList } from "@/components/dashboard/message-list";
import { KeywordTracking } from "@/components/dashboard/keyword-tracking";
import { DEMO_USER_ID, PLATFORM_DATA } from "@/lib/constants";
import { formatDateRelative, getCurrentInterval, getDateRangeFromInterval } from "@/lib/utils";
import { Activity, Message, SocialAccount, Keyword } from "@shared/schema";
import useAccounts from "@/hooks/use-accounts";

export default function Dashboard() {
  const [location, setLocation] = useLocation();
  const [chartPeriod, setChartPeriod] = useState<"daily" | "weekly" | "monthly" | "yearly">("weekly");
  const [engagementPlatform, setEngagementPlatform] = useState("all");
  
  const { accounts, isLoading: isLoadingAccounts, activeAccount, setActiveAccount } = useAccounts();
  
  // Fetch dashboard data
  const { data: dashboardData, isLoading: isLoadingDashboard } = useQuery({ 
    queryKey: [`/api/dashboard/${DEMO_USER_ID}`],
    enabled: !isLoadingAccounts
  });
  
  // Fetch activities
  const { data: activities, isLoading: isLoadingActivities } = useQuery({
    queryKey: [`/api/activities/user/${DEMO_USER_ID}?limit=5`],
    enabled: !isLoadingDashboard && !isLoadingAccounts
  });
  
  // Fetch messages
  const { data: messages, isLoading: isLoadingMessages } = useQuery({
    queryKey: [activeAccount ? `/api/messages/${activeAccount.id}` : null],
    enabled: !!activeAccount
  });
  
  // Fetch keywords
  const { data: keywords, isLoading: isLoadingKeywords } = useQuery({
    queryKey: [`/api/keywords/${DEMO_USER_ID}`],
    enabled: !isLoadingDashboard && !isLoadingAccounts
  });
  
  // Calculate unread message counts
  const unreadMessageCounts: Record<string, number> = {};
  if (accounts && dashboardData) {
    accounts.forEach(account => {
      unreadMessageCounts[account.id.toString()] = 0;
    });
  }
  
  const isLoading = isLoadingAccounts || isLoadingDashboard || isLoadingActivities || isLoadingMessages || isLoadingKeywords;
  
  // Prepare follower platform data for the bar chart
  const platformFollowers = accounts?.reduce((acc, account) => {
    if (account.stats?.followers) {
      acc.push({
        platform: account.platform,
        value: account.stats.followers, 
        label: account.platform === 'instagram' ? '54K' :
               account.platform === 'facebook' ? '23K' :
               account.platform === 'youtube' ? '32K' : '19.5K'
      });
    }
    return acc;
  }, [] as { platform: string; value: number; label?: string }[]) || [];
  
  // For weekly engagement chart data
  const weekdayLabels = ["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"];
  const weekdayData = [30, 45, 65, 100, 80, 60, 40];
  
  // For followers growth chart data
  const chartData = {
    labels: ["1 Oca", "15 Oca", "1 Şub", "15 Şub", "1 Mar", "15 Mar"],
    datasets: [
      {
        platform: "instagram",
        data: [140, 120, 100, 70, 40, 10],
      },
      {
        platform: "youtube",
        data: [170, 160, 150, 145, 100, 50],
      },
      {
        platform: "tiktok",
        data: [180, 170, 160, 140, 90, 30],
      },
      {
        platform: "facebook",
        data: [150, 145, 140, 130, 105, 75],
      },
    ],
  };
  
  // For engagement distribution chart data
  const engagementData = [
    { platform: "instagram", value: 14280, percentage: 42 },
    { platform: "youtube", value: 9576, percentage: 28 },
    { platform: "tiktok", value: 6156, percentage: 18 },
    { platform: "facebook", value: 4104, percentage: 12 },
  ];
  
  // Handle changing to messages page
  const handleViewAllMessages = () => {
    setLocation("/mesajlar");
  };
  
  // Handle changing to activities page
  const handleViewAllActivities = () => {
    setLocation("/analizler");
  };
  
  // Handle changing to keywords page
  const handleViewAllKeywords = () => {
    setLocation("/anahtar-kelimeler");
  };
  
  // Handle message click
  const handleMessageClick = (message: Message) => {
    setLocation("/mesajlar");
  };
  
  // Handle new message button
  const handleNewMessage = () => {
    setLocation("/mesajlar");
  };
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col md:flex-row bg-gray-50">
        <Sidebar 
          accounts={accounts || []}
          unreadMessageCounts={unreadMessageCounts}
          activeAccount={activeAccount}
          onAccountChange={setActiveAccount}
        />
        <div className="flex-1 p-8 flex items-center justify-center">
          <div className="loading-pulse">
            <div className="text-center">
              <i className="ri-loader-4-line text-4xl text-primary mb-4"></i>
              <p className="text-gray-600">Yükleniyor...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-gray-50">
      <Sidebar 
        accounts={accounts || []}
        unreadMessageCounts={unreadMessageCounts}
        activeAccount={activeAccount}
        onAccountChange={setActiveAccount}
      />
      
      <main className="flex-1 overflow-x-hidden">
        {/* Topbar */}
        <div className="bg-white border-b border-gray-200 px-4 py-4 flex items-center justify-between sticky top-0 z-10">
          <div>
            <h1 className="text-xl font-semibold text-gray-800">Genel Bakış</h1>
            <p className="text-sm text-gray-500">Tüm sosyal medya hesaplarınız için metrikleri görüntüleyin</p>
          </div>
          
          {/* Quick actions */}
          <div className="flex items-center space-x-3">
            <Button 
              variant="ghost" 
              size="icon" 
              className="p-2 text-gray-400 hover:text-gray-500 hover:bg-gray-100 rounded-full"
              onClick={() => window.alert('Arama özelliği yakında eklenecek')}
            >
              <i className="ri-search-line text-lg"></i>
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              className="p-2 text-gray-400 hover:text-gray-500 hover:bg-gray-100 rounded-full"
              onClick={() => window.alert('Bildirimler yakında eklenecek')}
            >
              <i className="ri-notification-3-line text-lg"></i>
            </Button>
            <Button 
              className="hidden md:flex items-center space-x-2 px-4 py-2 border border-primary text-primary rounded-lg text-sm font-medium hover:bg-primary-50"
              onClick={() => setLocation("/icerik-olustur")}
            >
              <i className="ri-add-line"></i>
              <span>Yeni İçerik</span>
            </Button>
          </div>
        </div>
        
        {/* Dashboard content */}
        <div className="p-4 md:p-6">
          {/* Overview section */}
          <div className="mb-8">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
              <h2 className="text-lg font-semibold text-gray-800 mb-2 md:mb-0">Haftalık Genel Bakış</h2>
              
              {/* Date range selector */}
              <div className="flex items-center">
                <Button 
                  variant="outline" 
                  className="flex items-center space-x-2 px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm text-gray-700"
                  onClick={() => window.alert('Tarih aralığı seçimi yakında eklenecek')}
                >
                  <span>Son 7 Gün</span>
                  <i className="ri-arrow-down-s-line"></i>
                </Button>
                
                <div className="ml-2 flex">
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="p-2 bg-white border border-gray-300 rounded-l-lg text-gray-500 hover:bg-gray-50"
                    onClick={() => window.alert('Önceki tarih aralığı yakında eklenecek')}
                  >
                    <i className="ri-arrow-left-s-line"></i>
                  </Button>
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="p-2 bg-white border border-gray-300 border-l-0 rounded-r-lg text-gray-500 hover:bg-gray-50"
                    onClick={() => window.alert('Sonraki tarih aralığı yakında eklenecek')}
                  >
                    <i className="ri-arrow-right-s-line"></i>
                  </Button>
                </div>
              </div>
            </div>
            
            {/* Stats cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <StatsCardWithPlatformBar
                title="Toplam Takipçi"
                value={dashboardData?.totalFollowers || 0}
                subtext="kullanıcı"
                change={12.5}
                platformValues={platformFollowers}
              />
              
              <StatsCardWithBarChart
                title="Etkileşim Oranı"
                value="4.7%"
                subtext="ortalama"
                change={-2.3}
                data={weekdayData}
                labels={weekdayLabels}
              />
              
              <StatsCardWithProgress
                title="Toplam Gösterim"
                value="1.4M"
                subtext="görüntülenme"
                change={35.8}
                progress={1400000}
                progressMax={2000000}
              />
              
              <StatsCard
                title="Yeni Mesajlar"
                value={dashboardData?.totalUnreadMessages || 0}
                subtext="okunmamış"
                changeText="Yeni"
              >
                <div className="mt-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-6 h-6 rounded-full bg-red-100 flex items-center justify-center mr-2">
                        <i className="ri-youtube-line text-red-600 text-xs"></i>
                      </div>
                      <span className="text-xs text-gray-700">YouTube</span>
                    </div>
                    <span className="text-xs font-medium">12</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-6 h-6 rounded-full bg-pink-100 flex items-center justify-center mr-2">
                        <i className="ri-instagram-line text-pink-600 text-xs"></i>
                      </div>
                      <span className="text-xs text-gray-700">Instagram</span>
                    </div>
                    <span className="text-xs font-medium">18</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center mr-2">
                        <i className="ri-facebook-circle-line text-blue-600 text-xs"></i>
                      </div>
                      <span className="text-xs text-gray-700">Facebook</span>
                    </div>
                    <span className="text-xs font-medium">7</span>
                  </div>
                </div>
              </StatsCard>
            </div>
            
            {/* Charts section */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <ChartGrowth 
                data={chartData} 
                period={chartPeriod} 
                onPeriodChange={setChartPeriod} 
              />
              
              <ChartEngagement 
                data={engagementData}
                totalEngagement={34200}
                selectedPlatform={engagementPlatform}
                onPlatformChange={setEngagementPlatform}
              />
            </div>
          </div>
          
          {/* Recent Activity and Messages section */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <ActivityFeed 
              activities={activities || []} 
              onViewAll={handleViewAllActivities}
            />
            
            <MessageList 
              messages={(messages || []).slice(0, 4)}
              onMessageClick={handleMessageClick}
              onNewMessage={handleNewMessage}
              onViewAll={handleViewAllMessages}
            />
          </div>
          
          {/* Keyword Tracking section */}
          <div className="mt-6">
            <KeywordTracking 
              keywords={keywords || []}
              onViewDetails={(keyword) => setLocation("/anahtar-kelimeler")}
              onAddKeyword={() => setLocation("/anahtar-kelimeler")}
              onSearchKeyword={(term) => console.log("Search:", term)}
            />
          </div>
        </div>
      </main>
    </div>
  );
}
