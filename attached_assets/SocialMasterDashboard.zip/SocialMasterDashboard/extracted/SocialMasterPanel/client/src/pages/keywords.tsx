import React, { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Sidebar from "@/components/dashboard/sidebar";
import { KeywordTracking } from "@/components/dashboard/keyword-tracking";
import { DEMO_USER_ID, PLATFORM_DATA, PLATFORMS } from "@/lib/constants";
import { useToast } from "@/hooks/use-toast";
import { Keyword } from "@shared/schema";
import useAccounts from "@/hooks/use-accounts";

const keywordFormSchema = z.object({
  keyword: z.string().min(1, { message: "Anahtar kelime gereklidir" }),
  platform: z.string().optional(),
  socialAccountId: z.number().optional(),
  userId: z.number(),
});

type KeywordFormValues = z.infer<typeof keywordFormSchema>;

export default function Keywords() {
  const { toast } = useToast();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isDetailsDialogOpen, setIsDetailsDialogOpen] = useState(false);
  const [selectedKeyword, setSelectedKeyword] = useState<Keyword | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [activePlatform, setActivePlatform] = useState("all");
  
  const { accounts, isLoading: isLoadingAccounts, activeAccount, setActiveAccount } = useAccounts();
  
  // Fetch keywords
  const { data: keywords, isLoading: isLoadingKeywords } = useQuery({
    queryKey: [`/api/keywords/${DEMO_USER_ID}`]
  });
  
  // Calculate unread message counts
  const unreadMessageCounts: Record<string, number> = {};
  
  // Add keyword mutation
  const addKeywordMutation = useMutation({
    mutationFn: async (keywordData: KeywordFormValues) => {
      return apiRequest("POST", "/api/keywords", keywordData);
    },
    onSuccess: () => {
      toast({
        title: "Anahtar kelime eklendi",
        description: "Yeni anahtar kelime başarıyla eklendi.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/keywords/${DEMO_USER_ID}`] });
      setIsAddDialogOpen(false);
      form.reset();
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Hata",
        description: "Anahtar kelime eklenirken bir hata oluştu.",
      });
    }
  });
  
  // Delete keyword mutation
  const deleteKeywordMutation = useMutation({
    mutationFn: async (keywordId: number) => {
      return apiRequest("DELETE", `/api/keywords/${keywordId}`, null);
    },
    onSuccess: () => {
      toast({
        title: "Anahtar kelime silindi",
        description: "Anahtar kelime başarıyla silindi.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/keywords/${DEMO_USER_ID}`] });
      setIsDetailsDialogOpen(false);
      setSelectedKeyword(null);
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Hata",
        description: "Anahtar kelime silinirken bir hata oluştu.",
      });
    }
  });
  
  // Setup form
  const form = useForm<KeywordFormValues>({
    resolver: zodResolver(keywordFormSchema),
    defaultValues: {
      keyword: "",
      platform: undefined,
      socialAccountId: undefined,
      userId: DEMO_USER_ID,
    },
  });
  
  // Handle form submission
  const onSubmit = (values: KeywordFormValues) => {
    addKeywordMutation.mutate(values);
  };
  
  // Handle view keyword details
  const handleViewKeywordDetails = (keyword: Keyword) => {
    setSelectedKeyword(keyword);
    setIsDetailsDialogOpen(true);
  };
  
  // Handle delete keyword
  const handleDeleteKeyword = () => {
    if (selectedKeyword) {
      deleteKeywordMutation.mutate(selectedKeyword.id);
    }
  };
  
  // Filter keywords based on active platform and search term
  const filteredKeywords = keywords?.filter(keyword => {
    const matchesPlatform = activePlatform === "all" || keyword.platform === activePlatform;
    const matchesSearch = !searchTerm || 
      keyword.keyword.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesPlatform && matchesSearch;
  }) || [];
  
  const isLoading = isLoadingAccounts || isLoadingKeywords;
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col md:flex-row bg-gray-50">
        <Sidebar 
          accounts={accounts || []}
          unreadMessageCounts={unreadMessageCounts}
          activeAccount={activeAccount}
          onAccountChange={setActiveAccount}
        />
        <div className="flex-1 p-8 flex items-center justify-center">
          <div className="loading-pulse">
            <div className="text-center">
              <i className="ri-loader-4-line text-4xl text-primary mb-4"></i>
              <p className="text-gray-600">Anahtar kelimeler yükleniyor...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  // Random sentiment change data for the chart
  const sentimentData = Array.from({ length: 7 }, (_, i) => ({
    date: new Date(Date.now() - (6-i) * 24 * 60 * 60 * 1000).toLocaleDateString('tr-TR', { day: 'numeric', month: 'short' }),
    value: selectedKeyword ? 
      Math.max(25, Math.min(85, selectedKeyword.sentiment + Math.floor(Math.random() * 20) - 10)) : 
      65
  }));
  
  // Random mentions data for the chart
  const mentionsData = Array.from({ length: 7 }, (_, i) => ({
    date: new Date(Date.now() - (6-i) * 24 * 60 * 60 * 1000).toLocaleDateString('tr-TR', { day: 'numeric', month: 'short' }),
    value: selectedKeyword ? 
      Math.max(500, Math.min(3000, selectedKeyword.mentions / 7 + Math.floor(Math.random() * 300) - 150)) : 
      1000
  }));
  
  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-gray-50">
      <Sidebar 
        accounts={accounts || []}
        unreadMessageCounts={unreadMessageCounts}
        activeAccount={activeAccount}
        onAccountChange={setActiveAccount}
      />
      
      <main className="flex-1 overflow-x-hidden">
        {/* Topbar */}
        <div className="bg-white border-b border-gray-200 px-4 py-4 flex items-center justify-between sticky top-0 z-10">
          <div>
            <h1 className="text-xl font-semibold text-gray-800">Anahtar Kelimeler</h1>
            <p className="text-sm text-gray-500">Markalarınız ve ürünleriniz hakkında konuşmaları takip edin</p>
          </div>
          
          {/* Actions */}
          <div className="flex items-center space-x-3">
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <i className="ri-add-line mr-2"></i>
                  Yeni Anahtar Kelime
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Yeni Anahtar Kelime Ekle</DialogTitle>
                  <DialogDescription>
                    Takip etmek istediğiniz anahtar kelimeyi girin. Başına # ekleyerek hashtag takibi yapabilirsiniz.
                  </DialogDescription>
                </DialogHeader>
                
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="keyword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Anahtar Kelime</FormLabel>
                          <FormControl>
                            <Input placeholder="#AcmeMarka veya 'Ürün İncelemesi'" {...field} />
                          </FormControl>
                          <FormDescription>
                            Takip etmek istediğiniz kelime veya cümle
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="platform"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Platform</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Platform seçin (opsiyonel)" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="">Tüm Platformlar</SelectItem>
                              {PLATFORMS.map(platform => (
                                <SelectItem key={platform} value={platform}>
                                  {PLATFORM_DATA[platform].label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            Belirli bir platform seçebilir veya tüm platformlarda takip yapabilirsiniz
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="socialAccountId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Hesap</FormLabel>
                          <Select
                            onValueChange={(value) => field.onChange(parseInt(value) || undefined)}
                            value={field.value?.toString()}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Hesap seçin (opsiyonel)" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="">Tüm Hesaplar</SelectItem>
                              {accounts?.map(account => (
                                <SelectItem key={account.id} value={account.id.toString()}>
                                  {account.name} ({PLATFORM_DATA[account.platform].label})
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            Belirli bir hesap ile ilişkilendirebilir veya genel takip yapabilirsiniz
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <DialogFooter>
                      <Button 
                        type="submit" 
                        disabled={addKeywordMutation.isPending}
                      >
                        {addKeywordMutation.isPending && (
                          <i className="ri-loader-4-line animate-spin mr-2"></i>
                        )}
                        Anahtar Kelime Ekle
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </div>
        
        {/* Keywords content */}
        <div className="p-4 md:p-6">
          {/* Platform Tabs */}
          <Tabs defaultValue="all" value={activePlatform} onValueChange={setActivePlatform} className="mb-6">
            <TabsList className="w-full max-w-lg mx-auto grid grid-cols-5">
              <TabsTrigger value="all">Tümü</TabsTrigger>
              <TabsTrigger value="instagram" className="instagram-color">Instagram</TabsTrigger>
              <TabsTrigger value="youtube" className="youtube-color">YouTube</TabsTrigger>
              <TabsTrigger value="tiktok" className="tiktok-color">TikTok</TabsTrigger>
              <TabsTrigger value="facebook" className="facebook-color">Facebook</TabsTrigger>
            </TabsList>
          </Tabs>
          
          {/* Keywords table */}
          <KeywordTracking 
            keywords={filteredKeywords}
            onAddKeyword={() => setIsAddDialogOpen(true)}
            onSearchKeyword={setSearchTerm}
            onViewDetails={handleViewKeywordDetails}
          />
          
          {/* Keyword details dialog */}
          <Dialog open={isDetailsDialogOpen} onOpenChange={setIsDetailsDialogOpen}>
            <DialogContent className="max-w-4xl">
              <DialogHeader>
                <DialogTitle>Anahtar Kelime Detayları</DialogTitle>
                <DialogDescription>
                  {selectedKeyword?.keyword} anahtar kelimesi için detaylı veriler
                </DialogDescription>
              </DialogHeader>
              
              {selectedKeyword && (
                <div className="mt-4 space-y-6">
                  {/* Keyword info */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardContent className="p-4">
                        <div className="text-sm font-medium text-gray-500 mb-1">Platform</div>
                        <div className="flex items-center">
                          {selectedKeyword.platform ? (
                            <>
                              <i className={`${PLATFORM_DATA[selectedKeyword.platform].iconClass} text-lg ${PLATFORM_DATA[selectedKeyword.platform].color} mr-1`}></i>
                              <span className="text-lg font-semibold">{PLATFORM_DATA[selectedKeyword.platform].label}</span>
                            </>
                          ) : (
                            <span className="text-lg font-semibold">Tüm Platformlar</span>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-4">
                        <div className="text-sm font-medium text-gray-500 mb-1">Toplam Bahsedilme</div>
                        <div className="text-lg font-semibold">
                          {selectedKeyword.mentions.toLocaleString()}
                          <span className={`ml-2 text-sm ${selectedKeyword.changePercentage >= 0 ? "text-green-600" : "text-red-600"}`}>
                            <i className={`${selectedKeyword.changePercentage >= 0 ? "ri-arrow-up-line" : "ri-arrow-down-line"}`}></i>
                            {Math.abs(selectedKeyword.changePercentage)}%
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-4">
                        <div className="text-sm font-medium text-gray-500 mb-1">Sentiment Skoru</div>
                        <div className="flex items-center">
                          <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden mr-2">
                            <div 
                              className={`h-full rounded-full ${
                                selectedKeyword.sentiment >= 70 ? "bg-green-400" : 
                                selectedKeyword.sentiment >= 50 ? "bg-green-400" : 
                                selectedKeyword.sentiment >= 30 ? "bg-yellow-400" : 
                                "bg-red-400"
                              }`} 
                              style={{ width: `${selectedKeyword.sentiment}%` }}
                            ></div>
                          </div>
                          <span className="text-lg font-semibold">{selectedKeyword.sentiment}%</span>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                  
                  {/* Charts */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base font-medium">Bahsedilme Trendi</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="h-[250px]">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart
                              data={mentionsData}
                              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                            >
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="date" />
                              <YAxis />
                              <Tooltip />
                              <Line
                                type="monotone"
                                dataKey="value"
                                name="Bahsedilme"
                                stroke="#8B5CF6"
                                strokeWidth={2}
                                dot={{ r: 4 }}
                                activeDot={{ r: 6 }}
                              />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base font-medium">Sentiment Trendi</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="h-[250px]">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart
                              data={sentimentData}
                              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                            >
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="date" />
                              <YAxis domain={[0, 100]} />
                              <Tooltip />
                              <Line
                                type="monotone"
                                dataKey="value"
                                name="Sentiment"
                                stroke="#8B5CF6"
                                strokeWidth={2}
                                dot={{ r: 4 }}
                                activeDot={{ r: 6 }}
                              />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                  
                  {/* Example mentions - would be real in a production app */}
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base font-medium">Örnek Bahsedilmeler</CardTitle>
                    </CardHeader>
                    <CardContent className="p-0">
                      <div className="divide-y divide-gray-100">
                        <div className="p-4">
                          <div className="flex items-center mb-2">
                            <img 
                              src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" 
                              alt="User Avatar" 
                              className="w-8 h-8 rounded-full mr-3"
                            />
                            <div>
                              <div className="text-sm font-medium">Ahmet Yılmaz</div>
                              <div className="text-xs text-gray-500 flex items-center">
                                <i className={`${PLATFORM_DATA[selectedKeyword.platform || "instagram"].iconClass} mr-1 ${PLATFORM_DATA[selectedKeyword.platform || "instagram"].color}`}></i>
                                <span>2 saat önce</span>
                              </div>
                            </div>
                          </div>
                          <p className="text-sm text-gray-700">
                            Bugün <span className="font-medium text-primary">{selectedKeyword.keyword}</span> hakkında yeni bir gönderi paylaştım. Herkesin görüşlerini merak ediyorum!
                          </p>
                        </div>
                        
                        <div className="p-4">
                          <div className="flex items-center mb-2">
                            <img 
                              src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" 
                              alt="User Avatar" 
                              className="w-8 h-8 rounded-full mr-3"
                            />
                            <div>
                              <div className="text-sm font-medium">Ayşe Demir</div>
                              <div className="text-xs text-gray-500 flex items-center">
                                <i className={`${PLATFORM_DATA[selectedKeyword.platform || "facebook"].iconClass} mr-1 ${PLATFORM_DATA[selectedKeyword.platform || "facebook"].color}`}></i>
                                <span>4 saat önce</span>
                              </div>
                            </div>
                          </div>
                          <p className="text-sm text-gray-700">
                            <span className="font-medium text-primary">{selectedKeyword.keyword}</span> ürünü hakkında çok olumlu deneyimlerim var. Herkese tavsiye ederim.
                          </p>
                        </div>
                        
                        <div className="p-4">
                          <div className="flex items-center mb-2">
                            <img 
                              src="https://images.unsplash.com/photo-1519244703995-f4e0f30006d5?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" 
                              alt="User Avatar" 
                              className="w-8 h-8 rounded-full mr-3"
                            />
                            <div>
                              <div className="text-sm font-medium">Mehmet Kaya</div>
                              <div className="text-xs text-gray-500 flex items-center">
                                <i className={`${PLATFORM_DATA[selectedKeyword.platform || "youtube"].iconClass} mr-1 ${PLATFORM_DATA[selectedKeyword.platform || "youtube"].color}`}></i>
                                <span>1 gün önce</span>
                              </div>
                            </div>
                          </div>
                          <p className="text-sm text-gray-700">
                            Yeni video serimde <span className="font-medium text-primary">{selectedKeyword.keyword}</span> hakkında detaylı bir inceleme yaptım. Linkte bulabilirsiniz!
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <DialogFooter className="flex justify-between">
                    <Button variant="destructive" onClick={handleDeleteKeyword}>
                      <i className="ri-delete-bin-line mr-2"></i>
                      Anahtar Kelimeyi Sil
                    </Button>
                    <Button variant="outline" onClick={() => setIsDetailsDialogOpen(false)}>
                      Kapat
                    </Button>
                  </DialogFooter>
                </div>
              )}
            </DialogContent>
          </Dialog>
        </div>
      </main>
    </div>
  );
}
