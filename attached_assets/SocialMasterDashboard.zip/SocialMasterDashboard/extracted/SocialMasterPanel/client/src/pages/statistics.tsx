import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Sidebar from "@/components/dashboard/sidebar";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DEMO_USER_ID, PLATFORM_DATA, TIME_INTERVALS } from "@/lib/constants";
import { StatsCard, StatsCardWithPlatformBar } from "@/components/dashboard/stats-card";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  Cell,
  LineChart,
  Line,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from "recharts";
import useAccounts from "@/hooks/use-accounts";
import useDateRange from "@/hooks/use-date-range";

export default function Statistics() {
  const { accounts, isLoading: isLoadingAccounts, activeAccount, setActiveAccount } = useAccounts();
  const { dateRange, selectedInterval, setSelectedInterval } = useDateRange();
  const [activePlatform, setActivePlatform] = useState("all");
  
  // Calculate unread message counts
  const unreadMessageCounts: Record<string, number> = {};
  
  // Fetch analytics data
  const { data: analyticsData, isLoading: isLoadingAnalytics } = useQuery({
    queryKey: [
      activeAccount ? 
        `/api/analytics/${activeAccount.id}?startDate=${dateRange.startDate.toISOString()}&endDate=${dateRange.endDate.toISOString()}` 
        : null
    ],
    enabled: !!activeAccount
  });
  
  const isLoading = isLoadingAccounts || isLoadingAnalytics;
  
  // Age distribution data
  const ageDistribution = [
    { name: "13-17", value: 5 },
    { name: "18-24", value: 35 },
    { name: "25-34", value: 30 },
    { name: "35-44", value: 15 },
    { name: "45-54", value: 10 },
    { name: "55+", value: 5 },
  ];
  
  // Gender distribution data
  const genderDistribution = [
    { name: "Kadın", value: 64 },
    { name: "Erkek", value: 35 },
    { name: "Diğer", value: 1 },
  ];
  
  // Country distribution data
  const countryDistribution = [
    { name: "Türkiye", value: 75 },
    { name: "Almanya", value: 8 },
    { name: "A.B.D.", value: 5 },
    { name: "İngiltere", value: 4 },
    { name: "Fransa", value: 3 },
    { name: "Diğer", value: 5 },
  ];
  
  // Content performance data
  const contentPerformance = [
    { name: "Fotoğraf", impressions: 45000, engagement: 3200 },
    { name: "Video", impressions: 32000, engagement: 2800 },
    { name: "Hikaye", impressions: 28000, engagement: 1500 },
    { name: "Canlı Yayın", impressions: 15000, engagement: 1200 },
    { name: "Reels", impressions: 52000, engagement: 4500 },
  ];
  
  // Engagement by day of week
  const weeklyEngagement = [
    { name: "Pazartesi", engagement: 850 },
    { name: "Salı", engagement: 950 },
    { name: "Çarşamba", engagement: 1100 },
    { name: "Perşembe", engagement: 1300 },
    { name: "Cuma", engagement: 1500 },
    { name: "Cumartesi", engagement: 1200 },
    { name: "Pazar", engagement: 900 },
  ];
  
  // Engagement by hour
  const hourlyEngagement = Array.from({ length: 24 }, (_, i) => ({
    hour: i,
    engagement: Math.floor(Math.random() * 500) + 100,
  }));
  
  // Radar chart data for content categories
  const contentCategoriesData = [
    { subject: 'Ürün', A: 85, fullMark: 100 },
    { subject: 'Eğitim', A: 65, fullMark: 100 },
    { subject: 'Haber', A: 45, fullMark: 100 },
    { subject: 'Eğlence', A: 90, fullMark: 100 },
    { subject: 'Moda', A: 70, fullMark: 100 },
    { subject: 'Teknoloji', A: 60, fullMark: 100 },
  ];
  
  // Platform specific colors
  const platformColors = {
    instagram: "#E1306C",
    youtube: "#FF0000",
    tiktok: "#000000",
    facebook: "#4267B2",
  };
  
  // Gender colors
  const genderColors = ["#8B5CF6", "#EC4899", "#6B7280"];
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col md:flex-row bg-gray-50">
        <Sidebar 
          accounts={accounts || []}
          unreadMessageCounts={unreadMessageCounts}
          activeAccount={activeAccount}
          onAccountChange={setActiveAccount}
        />
        <div className="flex-1 p-8 flex items-center justify-center">
          <div className="loading-pulse">
            <div className="text-center">
              <i className="ri-loader-4-line text-4xl text-primary mb-4"></i>
              <p className="text-gray-600">İstatistikler yükleniyor...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-gray-50">
      <Sidebar 
        accounts={accounts || []}
        unreadMessageCounts={unreadMessageCounts}
        activeAccount={activeAccount}
        onAccountChange={setActiveAccount}
      />
      
      <main className="flex-1 overflow-x-hidden">
        {/* Topbar */}
        <div className="bg-white border-b border-gray-200 px-4 py-4 flex items-center justify-between sticky top-0 z-10">
          <div>
            <h1 className="text-xl font-semibold text-gray-800">İstatistikler</h1>
            <p className="text-sm text-gray-500">
              {activeAccount 
                ? `${activeAccount.name} hesabı için detaylı istatistikler` 
                : "Sosyal medya istatistiklerini analiz edin"}
            </p>
          </div>
          
          {/* Date selector */}
          <div className="flex items-center space-x-3">
            <Select value={selectedInterval} onValueChange={setSelectedInterval}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Zaman aralığı" />
              </SelectTrigger>
              <SelectContent>
                {TIME_INTERVALS.map(interval => (
                  <SelectItem key={interval.value} value={interval.value}>
                    {interval.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Button variant="outline">
              <i className="ri-download-line mr-2"></i>
              Rapor İndir
            </Button>
          </div>
        </div>
        
        {/* Statistics content */}
        <div className="p-4 md:p-6">
          {/* Platform Tabs */}
          <Tabs defaultValue="all" value={activePlatform} onValueChange={setActivePlatform} className="mb-6">
            <TabsList className="w-full max-w-lg mx-auto grid grid-cols-5">
              <TabsTrigger value="all">Tümü</TabsTrigger>
              <TabsTrigger value="instagram" className="instagram-color">Instagram</TabsTrigger>
              <TabsTrigger value="youtube" className="youtube-color">YouTube</TabsTrigger>
              <TabsTrigger value="tiktok" className="tiktok-color">TikTok</TabsTrigger>
              <TabsTrigger value="facebook" className="facebook-color">Facebook</TabsTrigger>
            </TabsList>
          </Tabs>
          
          {/* Summary cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <StatsCard
              title="Toplam Takipçi"
              value="128.5K"
              subtext="kullanıcı"
              change={12.5}
            />
            
            <StatsCard
              title="Ortalama Etkileşim"
              value="4.7%"
              subtext="oran"
              change={-2.3}
            />
            
            <StatsCard
              title="İçerik Sayısı"
              value="734"
              subtext="paylaşım"
              change={8.2}
            />
            
            <StatsCard
              title="Toplam Gösterim"
              value="1.4M"
              subtext="görüntülenme"
              change={35.8}
            />
          </div>
          
          {/* Audience Demographics */}
          <h2 className="text-lg font-semibold text-gray-800 mb-4">Kitle Demografisi</h2>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            {/* Age Distribution */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium">Yaş Dağılımı</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      layout="vertical"
                      data={ageDistribution}
                      margin={{ top: 20, right: 30, left: 40, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                      <XAxis type="number" />
                      <YAxis dataKey="name" type="category" />
                      <Tooltip 
                        formatter={(value: number) => [`${value}%`, "Oran"]}
                      />
                      <Bar dataKey="value" name="Yüzde" fill="#8B5CF6" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            {/* Gender Distribution */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium">Cinsiyet Dağılımı</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] flex items-center justify-center">
                  <ResponsiveContainer width="70%" height="100%">
                    <PieChart>
                      <Pie
                        data={genderDistribution}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {genderDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={genderColors[index]} />
                        ))}
                      </Pie>
                      <Tooltip 
                        formatter={(value: number) => [`${value}%`, ""]}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex justify-center mt-2 space-x-6">
                  {genderDistribution.map((entry, index) => (
                    <div key={index} className="flex items-center">
                      <div 
                        className="w-3 h-3 rounded-full mr-1"
                        style={{ backgroundColor: genderColors[index] }}
                      ></div>
                      <span className="text-sm">{entry.name}: {entry.value}%</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            {/* Location Distribution */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium">Coğrafi Dağılım</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      layout="vertical"
                      data={countryDistribution}
                      margin={{ top: 20, right: 30, left: 40, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                      <XAxis type="number" />
                      <YAxis dataKey="name" type="category" />
                      <Tooltip 
                        formatter={(value: number) => [`${value}%`, "Oran"]}
                      />
                      <Bar dataKey="value" name="Yüzde" fill="#8B5CF6" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Content Performance */}
          <h2 className="text-lg font-semibold text-gray-800 mb-4">İçerik Performansı</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            {/* Content Type Performance */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium">İçerik Türü Performansı</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={contentPerformance}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="name" />
                      <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
                      <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
                      <Tooltip />
                      <Legend />
                      <Bar yAxisId="left" dataKey="impressions" name="Gösterimler" fill="#8B5CF6" />
                      <Bar yAxisId="right" dataKey="engagement" name="Etkileşimler" fill="#EC4899" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            {/* Content Categories */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium">İçerik Kategorileri</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart cx="50%" cy="50%" outerRadius="80%" data={contentCategoriesData}>
                      <PolarGrid />
                      <PolarAngleAxis dataKey="subject" />
                      <PolarRadiusAxis angle={30} domain={[0, 100]} />
                      <Radar name="Performans" dataKey="A" stroke="#8B5CF6" fill="#8B5CF6" fillOpacity={0.6} />
                      <Tooltip />
                      <Legend />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Engagement Timing */}
          <h2 className="text-lg font-semibold text-gray-800 mb-4">Etkileşim Zamanlaması</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            {/* Weekly Engagement */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium">Haftalık Etkileşim</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={weeklyEngagement}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip 
                        formatter={(value: number) => [value.toLocaleString(), "Etkileşim"]}
                      />
                      <Bar dataKey="engagement" name="Etkileşim" fill="#8B5CF6" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            {/* Hourly Engagement */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium">Saatlik Etkileşim</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={hourlyEngagement}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="hour" 
                        tickFormatter={(hour) => `${hour}:00`}
                      />
                      <YAxis />
                      <Tooltip 
                        formatter={(value: number) => [value.toLocaleString(), "Etkileşim"]}
                        labelFormatter={(hour) => `Saat: ${hour}:00`}
                      />
                      <Line
                        type="monotone"
                        dataKey="engagement"
                        name="Etkileşim"
                        stroke="#8B5CF6"
                        strokeWidth={2}
                        dot={{ r: 3 }}
                        activeDot={{ r: 5 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
