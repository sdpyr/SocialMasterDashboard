import React from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { getAvatarFallback } from "@/lib/utils";

interface AvatarStackProps {
  avatars: {
    src: string;
    name: string;
  }[];
  limit?: number;
  size?: "sm" | "md" | "lg";
}

export function AvatarStack({ avatars, limit = 3, size = "md" }: AvatarStackProps) {
  const displayAvatars = avatars.slice(0, limit);
  const extras = avatars.length - limit;

  const sizeClass = {
    sm: "h-6 w-6 text-xs",
    md: "h-8 w-8 text-sm",
    lg: "h-10 w-10 text-base",
  };

  const offsetClass = {
    sm: "-ml-2",
    md: "-ml-3",
    lg: "-ml-4",
  };

  return (
    <div className="flex items-center">
      {displayAvatars.map((avatar, i) => (
        <Avatar
          key={i}
          className={`${sizeClass[size]} border-2 border-white ${i !== 0 ? offsetClass[size] : ""}`}
        >
          <AvatarImage src={avatar.src} alt={avatar.name} />
          <AvatarFallback>{getAvatarFallback(avatar.name)}</AvatarFallback>
        </Avatar>
      ))}
      {extras > 0 && (
        <div
          className={`${sizeClass[size]} ${offsetClass[size]} flex items-center justify-center bg-gray-100 text-gray-600 rounded-full border-2 border-white`}
        >
          +{extras}
        </div>
      )}
    </div>
  );
}
