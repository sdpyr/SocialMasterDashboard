import * as React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface DataTableColumn<T> {
  id: string;
  header: string;
  cell: (row: T) => React.ReactNode;
  className?: string;
}

interface DataTableProps<T> {
  columns: DataTableColumn<T>[];
  data: T[];
  searchable?: boolean;
  searchColumn?: string;
  pageSizeOptions?: number[];
  pageCount?: number;
  pagination?: boolean;
  onSearch?: (value: string) => void;
  onPaginationChange?: (page: number, pageSize: number) => void;
}

export function DataTable<T>({
  columns,
  data,
  searchable = false,
  searchColumn,
  pageSizeOptions = [10, 20, 30, 40, 50],
  pageCount = 1,
  pagination = true,
  onSearch,
  onPaginationChange,
}: DataTableProps<T>) {
  const [searchTerm, setSearchTerm] = React.useState("");
  const [pageSize, setPageSize] = React.useState(pageSizeOptions[0]);
  const [currentPage, setCurrentPage] = React.useState(1);

  const handleSearch = (value: string) => {
    setSearchTerm(value);
    if (onSearch) {
      onSearch(value);
    }
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    if (onPaginationChange) {
      onPaginationChange(page, pageSize);
    }
  };

  const handlePageSizeChange = (value: string) => {
    const newPageSize = parseInt(value);
    setPageSize(newPageSize);
    setCurrentPage(1);
    if (onPaginationChange) {
      onPaginationChange(1, newPageSize);
    }
  };

  const paginationControls = () => {
    if (!pagination) return null;

    return (
      <div className="px-6 py-3 flex items-center justify-between border-t border-gray-200">
        <div className="flex items-center text-sm text-gray-500">
          <span>
            {1 + (currentPage - 1) * pageSize}-
            {Math.min(currentPage * pageSize, data.length)} / {data.length} sonuç gösteriliyor
          </span>
        </div>

        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="icon"
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
            className="p-1.5 bg-white border border-gray-300 rounded text-gray-400"
          >
            <i className="ri-arrow-left-s-line text-sm"></i>
          </Button>

          {Array.from({ length: Math.min(3, pageCount) }, (_, i) => {
            // Show pages around current page
            let pageNum = currentPage;
            if (i === 0 && currentPage > 1) pageNum = currentPage - 1;
            else if (i === 2 && currentPage < pageCount) pageNum = currentPage + 1;
            else if (i === 0) pageNum = 1;
            else if (i === 2) pageNum = pageCount;

            // Don't show page numbers out of range
            if (pageNum < 1 || pageNum > pageCount) return null;

            const isActive = pageNum === currentPage;
            return (
              <Button
                key={`page-${pageNum}`}
                variant={isActive ? "outline" : "outline"}
                onClick={() => handlePageChange(pageNum)}
                className={`px-3 py-1 border ${
                  isActive
                    ? "bg-primary-50 border-primary text-primary text-sm font-medium"
                    : "bg-white border-gray-300 rounded text-gray-600 text-sm"
                }`}
              >
                {pageNum}
              </Button>
            );
          })}

          <Button
            variant="outline"
            size="icon"
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === pageCount}
            className="p-1.5 bg-white border border-gray-300 rounded text-gray-600"
          >
            <i className="ri-arrow-right-s-line text-sm"></i>
          </Button>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-4">
      {searchable && (
        <div className="flex items-center justify-between mb-4">
          <div className="relative">
            <Input
              placeholder={`Arama yap...`}
              value={searchTerm}
              onChange={(e) => handleSearch(e.target.value)}
              className="pl-8 pr-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            />
            <i className="ri-search-line absolute left-2.5 top-2 text-gray-400 text-sm"></i>
          </div>
          {pageSizeOptions.length > 1 && (
            <Select
              value={pageSize.toString()}
              onValueChange={handlePageSizeChange}
            >
              <SelectTrigger className="w-[120px]">
                <SelectValue placeholder="Sayfa boyutu" />
              </SelectTrigger>
              <SelectContent>
                {pageSizeOptions.map((option) => (
                  <SelectItem key={option} value={option.toString()}>
                    {option} sonuç
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>
      )}

      <div className="overflow-x-auto">
        <Table>
          <TableHeader className="bg-gray-50">
            <TableRow>
              {columns.map((column) => (
                <TableHead
                  key={column.id}
                  className={`px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider ${column.className || ""}`}
                >
                  {column.header}
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody className="bg-white divide-y divide-gray-200">
            {data.length === 0 ? (
              <TableRow>
                <TableCell colSpan={columns.length} className="px-6 py-4 text-center text-gray-500">
                  Veri bulunamadı
                </TableCell>
              </TableRow>
            ) : (
              data.map((row, rowIndex) => (
                <TableRow key={rowIndex}>
                  {columns.map((column) => (
                    <TableCell
                      key={`${rowIndex}-${column.id}`}
                      className={`px-6 py-4 whitespace-nowrap ${column.className || ""}`}
                    >
                      {column.cell(row)}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {pagination && paginationControls()}
    </div>
  );
}
