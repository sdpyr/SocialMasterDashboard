import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import Providers from "@/components/providers";
import { lazy, Suspense } from "react";
import { Loader2 } from "lucide-react";

// Lazy loaded components
const NotFound = lazy(() => import("@/pages/not-found"));
const Dashboard = lazy(() => import("@/pages/dashboard"));
const Messages = lazy(() => import("@/pages/messages"));
const Analytics = lazy(() => import("@/pages/analytics"));
const Statistics = lazy(() => import("@/pages/statistics"));
const Keywords = lazy(() => import("@/pages/keywords"));
const ContentCalendar = lazy(() => import("@/pages/content-calendar"));
const PlatformDetail = lazy(() => import("@/pages/platform-detail"));
const CreatePost = lazy(() => import("@/pages/create-post"));
const AdminPanel = lazy(() => import("@/pages/admin-panel"));
const UserSettings = lazy(() => import("@/pages/user-settings"));
const CommentAnalysis = lazy(() => import("@/pages/comment-analysis"));
const ContentGeneration = lazy(() => import("@/pages/content-generation"));

// Loading component
const LoadingPage = () => (
  <div className="min-h-screen flex items-center justify-center">
    <div className="flex flex-col items-center gap-4">
      <Loader2 className="w-10 h-10 text-primary animate-spin" />
      <p className="text-gray-500 font-medium">Yükleniyor...</p>
    </div>
  </div>
);

function Router() {
  return (
    <Suspense fallback={<LoadingPage />}>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/mesajlar" component={Messages} />
        <Route path="/analizler" component={Analytics} />
        <Route path="/istatistikler" component={Statistics} />
        <Route path="/anahtar-kelimeler" component={Keywords} />
        <Route path="/icerik-takvimi" component={ContentCalendar} />
        <Route path="/icerik-olustur" component={CreatePost} />
        <Route path="/platform/:platform" component={PlatformDetail} />
        <Route path="/ayarlar" component={UserSettings} />
        <Route path="/admin" component={AdminPanel} />
        <Route path="/yorum-analizi" component={CommentAnalysis} />
        <Route path="/icerik-uretimi" component={ContentGeneration} />
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

function App() {
  return (
    <Providers>
      <Router />
    </Providers>
  );
}

export default App;
