// i18n/en.ts
export const en = {
  // General
  appName: 'CrossPostHub',
  loading: 'Loading...',
  error: 'An error occurred',
  save: 'Save',
  cancel: 'Cancel',
  delete: 'Delete',
  edit: 'Edit',
  search: 'Search',
  filter: 'Filter',
  all: 'All',
  
  // Navigation
  dashboard: 'Dashboard',
  analytics: 'Analytics',
  content: 'Content',
  create: 'Create',
  calendar: 'Calendar',
  messages: 'Messages',
  keywords: 'Keywords',
  settings: 'Settings',
  admin: 'Admin',
  logout: 'Logout',

  // Login/Register
  login: 'Login',
  register: 'Register',
  username: 'Username',
  password: 'Password',
  email: 'Email',
  fullName: 'Full Name',
  forgotPassword: 'Forgot Password',
  
  // Dashboard
  welcomeMessage: 'Welcome',
  summary: 'Summary',
  totalFollowers: 'Total Followers',
  unreadMessages: 'Unread Messages',
  weeklyEngagement: 'Weekly Engagement',
  recentActivities: 'Recent Activities',
  quickStats: 'Quick Stats',
  
  // Content Creation
  createPost: 'Create Post',
  selectPlatforms: 'Select Platforms',
  preview: 'Preview',
  schedule: 'Schedule',
  postNow: 'Post Now',
  addMedia: 'Add Media',
  addText: 'Add Text',
  caption: 'Caption',
  hashtags: 'Hashtags',
  
  // Platforms
  instagram: 'Instagram',
  youtube: 'YouTube',
  tiktok: 'TikTok',
  facebook: 'Facebook',
  twitter: 'Twitter',
  linkedin: 'LinkedIn',
  
  // Messages
  inbox: 'Inbox',
  sent: 'Sent',
  drafts: 'Drafts',
  compose: 'Compose',
  reply: 'Reply',
  
  // Keywords
  addKeyword: 'Add Keyword',
  keywordPerformance: 'Keyword Performance',
  mentions: 'Mentions',
  sentiment: 'Sentiment',
  positive: 'Positive',
  negative: 'Negative',
  neutral: 'Neutral',
  
  // Settings
  accountSettings: 'Account Settings',
  profileSettings: 'Profile Settings',
  notificationSettings: 'Notification Settings',
  apiSettings: 'API Settings',
  languageSettings: 'Language Settings',
  securitySettings: 'Security Settings',
  changePassword: 'Change Password',
  
  // Admin Panel
  userManagement: 'User Management',
  subscriptionPlans: 'Subscription Plans',
  systemServices: 'System Services',
  apiKeys: 'API Keys',
  serviceMaintenance: 'Service Maintenance',
  
  // Subscription Plans
  freePlan: 'Free Plan',
  premiumPlan: 'Premium Plan',
  ultimatePlan: 'Ultimate Plan',
  upgrade: 'Upgrade',
  currentPlan: 'Current Plan',
  
  // System Services
  active: 'Active',
  maintenance: 'Maintenance',
  disabled: 'Disabled',
  activeFeatures: 'Active Features',
  
  // AI Features
  aiSuggestions: 'AI Suggestions',
  generateContent: 'Generate Content',
  analyzeComments: 'Analyze Comments',
  contentIdeas: 'Content Ideas',
  smartResponses: 'Smart Responses',
  
  // Analytics
  followers: 'Followers',
  engagement: 'Engagement',
  impressions: 'Impressions',
  reach: 'Reach',
  growth: 'Growth',
  demographics: 'Demographics',
  topContent: 'Top Content',
  performance: 'Performance',
  
  // Calendar
  today: 'Today',
  week: 'Week',
  month: 'Month',
  scheduledPosts: 'Scheduled Posts',
  upcomingPosts: 'Upcoming Posts',
  publishedPosts: 'Published Posts',
  
  // Errors and Warnings
  connectionError: 'Connection error occurred',
  authError: 'Authentication error',
  sessionExpired: 'Your session has expired, please log in again',
  invalidCredentials: 'Invalid username or password',
  requiredField: 'This field is required',
  
  // Confirmations
  confirmDelete: 'Are you sure you want to delete?',
  confirmLogout: 'Are you sure you want to log out?',
  confirmDiscard: 'Are you sure you want to discard changes?'
};