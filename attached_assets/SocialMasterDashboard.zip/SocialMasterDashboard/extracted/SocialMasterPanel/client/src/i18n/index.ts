// i18n/index.ts
import { tr } from './tr';
import { en } from './en';

export type Language = 'tr' | 'en';

export const supportedLanguages = {
  tr: 'Türkçe',
  en: 'English'
};

export const translations = {
  tr,
  en
};

export type TranslationKey = keyof typeof tr;

export const useTranslation = (lang: Language = 'tr') => {
  const t = (key: TranslationKey): string => {
    return translations[lang][key] || key;
  };

  return { t, currentLanguage: lang };
};