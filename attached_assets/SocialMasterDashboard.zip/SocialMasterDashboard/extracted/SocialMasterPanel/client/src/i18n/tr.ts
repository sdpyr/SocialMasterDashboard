// i18n/tr.ts
export const tr = {
  // Genel
  appName: 'CrossPostHub',
  loading: 'Yükleniyor...',
  error: 'Hata oluştu',
  save: 'Kaydet',
  cancel: 'İptal',
  delete: 'Sil',
  edit: 'Düzenle',
  search: 'Ara',
  filter: 'Filtrele',
  all: 'Tümü',
  
  // Navigation
  dashboard: 'Panel',
  analytics: 'Analitikler',
  content: 'İçerik',
  create: 'Oluştur',
  calendar: 'Takvim',
  messages: 'Mesajlar',
  keywords: 'Anahtar Kelimeler',
  settings: 'Ayarlar',
  admin: 'Yönetici',
  logout: 'Çıkış Yap',

  // Giriş/Kayıt
  login: 'Giriş Yap',
  register: 'Kayıt Ol',
  username: 'Kullanıcı Adı',
  password: 'Şifre',
  email: 'E-posta',
  fullName: 'Ad Soyad',
  forgotPassword: 'Şifremi Unuttum',
  
  // Dashboard
  welcomeMessage: 'Hoş Geldiniz',
  summary: 'Özet',
  totalFollowers: 'Toplam Takipçiler',
  unreadMessages: 'Okunmamış Mesajlar',
  weeklyEngagement: 'Haftalık Etkileşim',
  recentActivities: 'Son Aktiviteler',
  quickStats: 'Hızlı İstatistikler',
  
  // İçerik Oluşturma
  createPost: 'Gönderi Oluştur',
  selectPlatforms: 'Platform Seç',
  preview: 'Önizleme',
  schedule: 'Zamanla',
  postNow: 'Şimdi Paylaş',
  addMedia: 'Medya Ekle',
  addText: 'Metin Ekle',
  caption: 'Açıklama',
  hashtags: 'Etiketler',
  
  // Platformlar
  instagram: 'Instagram',
  youtube: 'YouTube',
  tiktok: 'TikTok',
  facebook: 'Facebook',
  twitter: 'Twitter',
  linkedin: 'LinkedIn',
  
  // Mesajlar
  inbox: 'Gelen Kutusu',
  sent: 'Gönderilmiş',
  drafts: 'Taslaklar',
  compose: 'Yeni Mesaj',
  reply: 'Yanıtla',
  
  // Anahtar Kelimeler
  addKeyword: 'Anahtar Kelime Ekle',
  keywordPerformance: 'Anahtar Kelime Performansı',
  mentions: 'Bahsedilmeler',
  sentiment: 'Duygu Analizi',
  positive: 'Olumlu',
  negative: 'Olumsuz',
  neutral: 'Nötr',
  
  // Ayarlar
  accountSettings: 'Hesap Ayarları',
  profileSettings: 'Profil Ayarları',
  notificationSettings: 'Bildirim Ayarları',
  apiSettings: 'API Ayarları',
  languageSettings: 'Dil Ayarları',
  securitySettings: 'Güvenlik Ayarları',
  changePassword: 'Şifre Değiştir',
  
  // Admin Panel
  userManagement: 'Kullanıcı Yönetimi',
  subscriptionPlans: 'Abonelik Planları',
  systemServices: 'Sistem Servisleri',
  apiKeys: 'API Anahtarları',
  serviceMaintenance: 'Servis Bakımı',
  
  // Abonelik Planları
  freePlan: 'Ücretsiz Plan',
  premiumPlan: 'Premium Plan',
  ultimatePlan: 'Ultimate Plan',
  upgrade: 'Yükselt',
  currentPlan: 'Mevcut Plan',
  
  // Sistem Servisleri
  active: 'Aktif',
  maintenance: 'Bakımda',
  disabled: 'Devre Dışı',
  activeFeatures: 'Aktif Özellikler',
  
  // AI Özellikleri
  aiSuggestions: 'AI Önerileri',
  generateContent: 'İçerik Oluştur',
  analyzeComments: 'Yorumları Analiz Et',
  contentIdeas: 'İçerik Fikirleri',
  smartResponses: 'Akıllı Yanıtlar',
  
  // Analitikler
  followers: 'Takipçiler',
  engagement: 'Etkileşim',
  impressions: 'Gösterimler',
  reach: 'Erişim',
  growth: 'Büyüme',
  demographics: 'Demografik',
  topContent: 'En İyi İçerikler',
  performance: 'Performans',
  
  // Takvim
  today: 'Bugün',
  week: 'Hafta',
  month: 'Ay',
  scheduledPosts: 'Zamanlanmış Gönderiler',
  upcomingPosts: 'Yaklaşan Gönderiler',
  publishedPosts: 'Yayınlanmış Gönderiler',
  
  // Hatalar ve Uyarılar
  connectionError: 'Bağlantı hatası oluştu',
  authError: 'Kimlik doğrulama hatası',
  sessionExpired: 'Oturumunuz sona erdi, lütfen tekrar giriş yapın',
  invalidCredentials: 'Geçersiz kullanıcı adı veya şifre',
  requiredField: 'Bu alan zorunludur',
  
  // Onaylar
  confirmDelete: 'Silmek istediğinize emin misiniz?',
  confirmLogout: 'Çıkış yapmak istediğinize emin misiniz?',
  confirmDiscard: 'Değişiklikleri iptal etmek istediğinize emin misiniz?'
};